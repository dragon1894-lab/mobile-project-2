using System;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProductionLine.AdminApp.Services;
using ProductionLine.Shared;

namespace ProductionLine.AdminApp
{
    public sealed class LineDetailForm : Form
    {
        private readonly int _lineId;
        private readonly IDashboardService _dashboardService;
        private readonly ILineDetailService _detailService;

        private readonly Label _summary = new Label();
        private readonly Label _status = new Label();
        private readonly Button _refresh = new Button();

        private readonly DataGridView _inspections = CreateGrid();
        private readonly DataGridView _issues = CreateGrid();

        private bool _loading;

        public LineDetailForm(
            int lineId,
            IDashboardService dashboardService,
            ILineDetailService detailService)
        {
            _lineId = lineId;
            _dashboardService = dashboardService;
            _detailService = detailService;

            Text = "대표 라인 상세";
            ClientSize = new Size(1100, 720);
            MinimumSize = new Size(900, 600);
            StartPosition = FormStartPosition.CenterParent;
            Font = new Font("맑은 고딕", 10F);
            BackColor = Color.FromArgb(244, 247, 251);

            BuildScreen();

            var autoRefresh = new System.Windows.Forms.Timer { Interval = 5000 };
            autoRefresh.Tick += async (_, _) => await LoadAsync();
            Shown += async (_, _) => { await LoadAsync(); if (!IsDisposed) autoRefresh.Start(); };
            FormClosed += (_, _) => autoRefresh.Dispose();
        }

        private void BuildScreen()
        {
            var root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(20),
                ColumnCount = 1,
                RowCount = 5
            };

            root.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 50));
            root.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 115));
            root.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 45));
            root.RowStyles.Add(
                new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 40));

            var title = new Label
            {
                Text = $"LINE {_lineId} · 대표 라인 상세",
                Dock = DockStyle.Fill,
                Font = new Font(
                    "맑은 고딕", 20F, FontStyle.Bold),
                ForeColor = Color.FromArgb(25, 45, 70),
                TextAlign = ContentAlignment.MiddleLeft
            };

            _summary.Dock = DockStyle.Fill;
            _summary.BackColor = Color.White;
            _summary.Padding = new Padding(15);
            _summary.Text = "라인 정보를 불러오는 중입니다.";
            _summary.TextAlign = ContentAlignment.MiddleLeft;

            var toolbar = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                WrapContents = false,
                Padding = new Padding(0, 5, 0, 0)
            };

            _refresh.Text = "새로고침";
            _refresh.AutoSize = true;
            _refresh.Click += async (_, _) => await LoadAsync();

            toolbar.Controls.Add(_refresh);
            toolbar.Controls.Add(new Label
            {
                Text = "검사 수량은 누적값, 아래 이력은 최근 조회 결과입니다.",
                AutoSize = true,
                ForeColor = Color.DimGray,
                Margin = new Padding(15, 7, 0, 0)
            });

            ConfigureColumns();

            var tabs = new TabControl
            {
                Dock = DockStyle.Fill
            };

            var inspectionPage = new TabPage("최근 검사 이력")
            {
                Padding = new Padding(5)
            };
            inspectionPage.Controls.Add(_inspections);

            var issuePage = new TabPage("라인 문제 목록")
            {
                Padding = new Padding(5)
            };
            issuePage.Controls.Add(_issues);

            tabs.TabPages.Add(inspectionPage);
            tabs.TabPages.Add(issuePage);

            _status.Dock = DockStyle.Fill;
            _status.TextAlign = ContentAlignment.MiddleLeft;
            _status.ForeColor = Color.DimGray;

            root.Controls.Add(title, 0, 0);
            root.Controls.Add(_summary, 0, 1);
            root.Controls.Add(toolbar, 0, 2);
            root.Controls.Add(tabs, 0, 3);
            root.Controls.Add(_status, 0, 4);

            Controls.Add(root);
        }

        private void ConfigureColumns()
        {
            AddColumn(_inspections, "Time", "검사 시각", 140);
            AddColumn(_inspections, "Result", "판정", 80);
            AddColumn(_inspections, "Confidence", "검출 신뢰도", 85);
            AddColumn(_inspections, "Shape", "형태 점수", 85);
            AddColumn(_inspections, "Color", "색상 점수", 85);
            AddColumn(_inspections, "Reason", "판정 사유", 260);

            _inspections.Columns["Time"]!
                .DefaultCellStyle.Format = "MM-dd HH:mm:ss";

            _inspections.CellFormatting += (_, e) =>
            {
                if (e.RowIndex < 0 || e.ColumnIndex < 0 || e.CellStyle is null ||
                    _inspections.Columns[e.ColumnIndex].Name
                        != "Result")
                    return;

                e.CellStyle.ForeColor =
                    Convert.ToString(e.Value) switch
                    {
                        "정상" => Color.SeaGreen,
                        "불량" => Color.Firebrick,
                        _ => Color.DarkOrange
                    };
            };

            AddColumn(_issues, "Title", "문제 제목", 180);
            AddColumn(_issues, "Type", "유형", 110);
            AddColumn(_issues, "Status", "상태", 100);
            AddColumn(_issues, "CreatedBy", "등록자", 90);
            AddColumn(_issues, "ActionNote", "조치 내용", 220);
            AddColumn(_issues, "UpdatedAt", "변경 시각", 140);

            _issues.Columns["UpdatedAt"]!
                .DefaultCellStyle.Format = "MM-dd HH:mm:ss";
        }

        private async Task LoadAsync()
        {
            if (_loading)
                return;

            _loading = true;
            _refresh.Enabled = false;
            _status.Text = "데이터를 불러오는 중입니다.";

            try
            {
                var linesTask = _dashboardService.GetLinesAsync();
                var issuesTask = _dashboardService.GetIssuesAsync();
                var inspectionsTask =
                    _detailService.GetInspectionsAsync(_lineId);

                await Task.WhenAll(
                    linesTask, issuesTask, inspectionsTask);

                if (IsDisposed || Disposing)
                    return;

                var lines = await linesTask;
                var line = lines.FirstOrDefault(
                    x => x.Id == _lineId);

                if (line == null)
                {
                    throw new InvalidOperationException(
                        "라인을 찾을 수 없거나 조회 권한이 없습니다.");
                }

                var issues = (await issuesTask)
                    .Where(x => x.LineId == _lineId)
                    .OrderByDescending(x => x.UpdatedAt)
                    .ToList();

                var inspections = (await inspectionsTask)
                    .OrderByDescending(x => x.InspectedAt)
                    .ToList();

                int determined =
                    line.NormalCount + line.DefectCount;

                string defectRate = determined == 0
                    ? "-"
                    : $"{line.DefectCount * 100.0 / determined:0.0}%";

                _summary.Text =
                    $"{line.Name}   |   " +
                    $"{(line.IsReal ? "실제 라인" : "가상 라인")}\r\n" +
                    $"가동 상태: {line.OperationStatus}   |   " +
                    $"검사 상태: {line.InspectionStatus}\r\n" +
                    $"정상: {line.NormalCount:N0}   " +
                    $"불량: {line.DefectCount:N0}   " +
                    $"판정 불가: {line.UndeterminedCount:N0}   " +
                    $"불량률: {defectRate}";

                _inspections.DataSource = inspections.Select(x => new
                {
                    Time = x.InspectedAt,
                    Result = ResultText(x.Result),
                    Confidence = x.DetectionConfidence?.ToString("P1") ?? "—",
                    Shape = x.DetectionConfidence.HasValue ? "—" : $"{x.ShapeScore:P0}",
                    Color = x.DetectionConfidence.HasValue ? "—" : $"{x.ColorScore:P0}",
                    x.Reason
                }).ToList();

                _issues.DataSource = issues.Select(x => new
                {
                    x.Title,
                    Type = x.Type == IssueType.ProductionLine
                        ? "생산라인"
                        : "검사 시스템",
                    Status = StatusText(x.Status),
                    x.CreatedBy,
                    ActionNote = x.ActionNote ?? "-",
                    x.UpdatedAt
                }).ToList();

                int pending = issues.Count(
                    x => x.Status == IssueStatus.CompletionRequested);

                _status.Text =
                    $"최근 검사 {inspections.Count}건   |   " +
                    $"문제 {issues.Count}건   |   " +
                    $"완료 요청 {pending}건   |   " +
                    $"라인 데이터 시각: {line.UpdatedAt:MM-dd HH:mm:ss}";
            }
            catch (Exception ex)
            {
                if (!IsDisposed && !Disposing)
                    _status.Text = "조회 실패: " + ex.Message;
            }
            finally
            {
                _loading = false;

                if (!IsDisposed && !Disposing)
                    _refresh.Enabled = true;
            }
        }

        private static string ResultText(
            InspectionResultType result)
        {
            return result switch
            {
                InspectionResultType.Normal => "정상",
                InspectionResultType.Defect => "불량",
                _ => "판정 불가"
            };
        }

        private static string StatusText(IssueStatus status)
        {
            return status switch
            {
                IssueStatus.Occurred => "발생",
                IssueStatus.Acknowledged => "확인",
                IssueStatus.InProgress => "조치 중",
                IssueStatus.CompletionRequested => "완료 요청",
                IssueStatus.Closed => "종결",
                _ => status.ToString()
            };
        }

        private static DataGridView CreateGrid()
        {
            return new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AutoGenerateColumns = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible = false,
                MultiSelect = false,
                SelectionMode =
                    DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode =
                    DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowTemplate = { Height = 36 }
            };
        }

        private static void AddColumn(
            DataGridView grid,
            string property,
            string title,
            float weight)
        {
            grid.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = property,
                DataPropertyName = property,
                HeaderText = title,
                FillWeight = weight,
                SortMode = DataGridViewColumnSortMode.NotSortable
            });
        }
    }
}
