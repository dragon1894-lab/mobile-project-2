using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ProductionLine.Shared;

namespace ProductionLine.AdminApp.Services
{
    public interface ILineDetailService
    {
        Task<List<InspectionDto>> GetInspectionsAsync(int lineId);
    }

    // 서버 없이 개발할 때 사용
    public sealed class MockLineDetailService : ILineDetailService
    {
        private readonly List<InspectionDto> _inspections =
            new List<InspectionDto>
            {
                new InspectionDto(
                    Guid.NewGuid(), 1,
                    InspectionResultType.Normal,
                    0.96, 0.94,
                    "형태·색상 기준 충족",
                    DateTimeOffset.Now.AddMinutes(-1)),

                new InspectionDto(
                    Guid.NewGuid(), 1,
                    InspectionResultType.Defect,
                    0.70, 0.93,
                    "형태 점수 기준 미달",
                    DateTimeOffset.Now.AddMinutes(-2)),

                new InspectionDto(
                    Guid.NewGuid(), 1,
                    InspectionResultType.Undetermined,
                    0, 0,
                    "영상 획득 실패",
                    DateTimeOffset.Now.AddMinutes(-3))
            };

        public Task<List<InspectionDto>> GetInspectionsAsync(
            int lineId)
        {
            return Task.FromResult(
                _inspections.FindAll(x => x.LineId == lineId));
        }
    }

    // 실제 서버 연결 시 사용
    public sealed class ApiLineDetailService : ILineDetailService
    {
        private readonly ProductionLineApiClient _api;

        public ApiLineDetailService(ProductionLineApiClient api)
        {
            _api = api;
        }

        public Task<List<InspectionDto>> GetInspectionsAsync(
            int lineId)
        {
            return _api.GetInspectionsAsync(lineId);
        }
    }
}