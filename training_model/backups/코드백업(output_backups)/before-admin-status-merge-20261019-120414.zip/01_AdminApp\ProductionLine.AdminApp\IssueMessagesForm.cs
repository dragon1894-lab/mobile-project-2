using ProductionLine.Shared;

namespace ProductionLine.AdminApp;

public sealed class IssueMessagesForm : Form
{
    private readonly ProductionLineApiClient _api;
    private readonly ComboBox _issues = new() { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly RichTextBox _messages = new() { Dock = DockStyle.Fill, ReadOnly = true };
    private readonly TextBox _input = new() { Dock = DockStyle.Fill, Multiline = true, MaxLength = 2000 };
    private readonly Button _send = new() { Text = "답장 보내기", Dock = DockStyle.Fill };
    private readonly Label _status = new() { Dock = DockStyle.Fill };
    private readonly System.Windows.Forms.Timer _timer = new() { Interval = 5000 };
    private readonly Dictionary<Guid, string> _drafts = new();
    private Guid? _selected;
    private bool _loading, _sending;

    public IssueMessagesForm(ProductionLineApiClient api)
    {
        _api = api;
        Text = "작업자 문의 · 문제별 관리자 대화";
        Size = new Size(850, 650); MinimumSize = new Size(700, 500);
        Font = new Font("맑은 고딕", 10); StartPosition = FormStartPosition.CenterParent;
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 5, ColumnCount = 1, Padding = new Padding(18) };
        foreach (var height in new[] { 42, 32 }) layout.RowStyles.Add(new RowStyle(SizeType.Absolute, height));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 80)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        layout.Controls.Add(_issues, 0, 0); layout.Controls.Add(_status, 0, 1); layout.Controls.Add(_messages, 0, 2);
        layout.Controls.Add(_input, 0, 3); layout.Controls.Add(_send, 0, 4); Controls.Add(layout);
        _issues.SelectedIndexChanged += async (_, _) =>
        {
            if (_selected is Guid previous) _drafts[previous] = _input.Text;
            _selected = (_issues.SelectedItem as IssueDto)?.Id;
            _input.Text = _selected is Guid id ? _drafts.GetValueOrDefault(id, "") : "";
            _messages.Clear(); await RefreshMessagesAsync();
        };
        _send.Click += async (_, _) =>
        {
            if (_sending || _issues.SelectedItem is not IssueDto issue || issue.Status == IssueStatus.Closed) return;
            var text = _input.Text.Trim(); if (text.Length == 0) return;
            _sending = true; _send.Enabled = false;
            try
            {
                await _api.SendIssueMessageAsync(issue.Id, text);
                _drafts.Remove(issue.Id);
                if (_selected == issue.Id && _input.Text.Trim() == text) _input.Clear();
                await RefreshMessagesAsync();
            }
            catch (Exception ex) { _status.Text = "전송 실패 · 입력 유지: " + ex.Message; }
            finally { _sending = false; if (!IsDisposed) _send.Enabled = (_issues.SelectedItem as IssueDto)?.Status != IssueStatus.Closed; }
        };
        _timer.Tick += async (_, _) => await RefreshMessagesAsync();
        Shown += async (_, _) =>
        {
            try { _issues.DisplayMember = nameof(IssueDto.Title); _issues.DataSource = await _api.GetIssuesAsync(); if (!IsDisposed) _timer.Start(); }
            catch (Exception ex) { _status.Text = ex.Message; }
        };
        FormClosed += (_, _) => _timer.Dispose();
    }

    private async Task RefreshMessagesAsync()
    {
        if (_loading || IsDisposed || _issues.SelectedItem is not IssueDto issue) return;
        _loading = true;
        try
        {
            var current = (await _api.GetIssuesAsync()).FirstOrDefault(x => x.Id == issue.Id);
            var messages = await _api.GetIssueMessagesAsync(issue.Id);
            if (IsDisposed || _selected != issue.Id) return;
            _send.Enabled = !_sending && current?.Status != IssueStatus.Closed;
            _input.ReadOnly = current?.Status == IssueStatus.Closed;
            _messages.Text = string.Join("\r\n\r\n", messages.Select(x => $"[{x.SenderRole} · {x.SenderName} · {x.CreatedAt.ToLocalTime():MM-dd HH:mm}]\r\n{x.Message}"));
            _status.Text = current?.Status == IssueStatus.Closed ? "종결된 문제 · 대화 조회만 가능합니다." : "5초마다 새 메시지를 확인합니다.";
        }
        catch (Exception ex) { if (!IsDisposed) _status.Text = ex.Message; }
        finally { _loading = false; }
    }
}
