using System;
using System.Threading.Tasks;
using ProductionLine.Shared;

namespace ProductionLine.AdminApp.Services
{
    public interface IAdminAuthService
    {
        Task<UserDto> LoginAsync(string id, string password);
    }

    // 서버 없이 사용하는 임시 로그인
    public sealed class MockAdminAuthService : IAdminAuthService
    {
        public Task<UserDto> LoginAsync(string id, string password)
        {
            bool validId = string.Equals(
                id.Trim(),
                "a",
                StringComparison.OrdinalIgnoreCase);

            if (!validId || password != "a1")
            {
                throw new InvalidOperationException(
                    "아이디 또는 비밀번호가 올바르지 않습니다.");
            }

            var user = new UserDto(
                Id: "admin",
                Name: "관리자",
                Role: UserRole.Admin,
                IsActive: true,
                AllowedLineIds: new[] { 1, 2, 3, 4 });

            return Task.FromResult(user);
        }
    }

    // 실제 서버 연결 시 사용하는 로그인
    public sealed class ApiAdminAuthService : IAdminAuthService
    {
        private readonly ProductionLineApiClient _api;

        public ApiAdminAuthService(ProductionLineApiClient api)
        {
            _api = api;
        }

        public async Task<UserDto> LoginAsync(string id, string password)
        {
            var user = await _api.LoginAsync(id, password);
            if (!user.IsActive || user.Role != UserRole.Admin)
                throw new InvalidOperationException("관리자 계정만 로그인할 수 있습니다.");
            return user;
        }
    }
}
