using System.Reflection;
using OpenCvSharp;
using ProductionLine.Shared;
using ProductionLine.UserApp;
using ProductionLine.Vision;

namespace ProductionLine.Verification;

internal static class MovingInspectionChecks
{
    private const BindingFlags Flags = BindingFlags.Instance | BindingFlags.NonPublic;
    private static T Field<T>(object instance, string name) => (T)instance.GetType().GetField(name, Flags)!.GetValue(instance)!;
    private static void Set(object instance, string name, object value) => instance.GetType().GetField(name, Flags)!.SetValue(instance, value);
    private static object? Call(object instance, string name, params object[] args) => instance.GetType().GetMethod(name, Flags)!.Invoke(instance, args);
    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
        Console.WriteLine("PASS: " + message);
    }

    public static void Run()
    {
        Application.SetHighDpiMode(HighDpiMode.SystemAware);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        var phone = File.ReadAllBytes(Environment.GetCommandLineArgs().Skip(2).First());
        using var blank = new Mat(1080, 1920, MatType.CV_8UC3, Scalar.Black);
        using var server = new TestServer();
        using var api = new ProductionLineApiClient(server.Url);
        api.LoginAsync("test", "test").GetAwaiter().GetResult();
        using var form = new UserMainForm(api);
        var feed = new MutableFeed(phone);
        var belt = new TestConveyor();
        form.Shown += async (_, _) =>
        {
            try
            {
                for (var i = 0; i < 200 && Field<bool>(form, "_loading"); i++) await Task.Delay(25);
                await (Task)Call(form, "RefreshAsync", false)!;
                Field<System.Windows.Forms.Timer>(form, "_refresh").Stop();
                Field<System.Windows.Forms.Timer>(form, "_frames").Stop();
                Set(form, "_camera", feed);
                Set(form, "_conveyor", belt);
                Check(!Field<CheckBox>(form, "_stopOnPhone").Checked, "detection never stops belt by default");
                Check(!Field<Button>(form, "_verificationAction").Visible && !Field<CheckBox>(form, "_autoResume").Visible,
                    "stationary inspection controls hidden in continuous mode");
                await (Task)Call(form, "RunConveyorAsync")!;
                Check(belt.IsRunning && belt.RunCount == 1, "manual RUN works before starting camera inspection");
                var start = (Task)Call(form, "StartInspectionAsync")!;
                Field<System.Windows.Forms.Timer>(form, "_inspectionTimer").Stop();
                await start;
                Check(belt.IsRunning && belt.StopCount == 0, "real ONNX phone recognition sends no STOP");
                Check(server.InspectionCount == 1 && Field<bool>(form, "_runningInspection"), "moving detection saves first product and continues");
                Check(server.LastCameraInspection is { ClassificationAvailable: false, Result: InspectionResultType.Undetermined, Confidence: >= 0.5 },
                    "moving inspection preserves measured confidence and unsupported quality");
                Check(Field<PictureBox>(form, "_video").Image != null, "YOLO result image displayed");
                Check(!Field<CheckBox>(form, "_stopOnPhone").Enabled, "mode cannot change during active inspection");
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(server.InspectionCount == 1 && belt.StopCount == 0, "same visible phone is not counted twice or stopped");
                feed.Image = blank.ToBytes(".jpg");
                await Task.Delay(300);
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(!Field<bool>(form, "_productPresent"), "empty image rearms next product");
                feed.Image = phone;
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(server.InspectionCount == 2 && belt.IsRunning && belt.StopCount == 0, "next phone recorded while belt keeps running");
                Call(form, "StopInspection", "test inspection stop");
                await Task.Delay(50);
                Check(!Field<bool>(form, "_runningInspection") && belt.IsRunning && belt.StopCount == 0,
                    "inspection stop controls detection separately from belt");
                Check(Field<CheckBox>(form, "_stopOnPhone").Enabled, "optional mode editable after inspection stop");
                start = (Task)Call(form, "StartInspectionAsync")!;
                Field<System.Windows.Forms.Timer>(form, "_inspectionTimer").Stop();
                await start;
                var stop = Field<Button>(form, "_conveyorStop");
                stop.Enabled = true;
                stop.PerformClick();
                await Task.Delay(50);
                Check(!belt.IsRunning && belt.StopCount == 1 && !Field<bool>(form, "_runningInspection"),
                    "explicit belt STOP stops both motor command and inspection");
                foreach (var size in new[] { new System.Drawing.Size(1400, 900), new System.Drawing.Size(1100, 740) })
                {
                    form.Size = size;
                    form.PerformLayout();
                    var toolbars = Field<Button>(form, "_inspectionStart").Parent!.Parent!.Controls.OfType<FlowLayoutPanel>().ToArray();
                    Check(toolbars.Length == 4 && toolbars.All(panel => panel.Controls.Cast<Control>().Where(c => c.Visible)
                        .All(c => panel.ClientRectangle.Contains(c.Bounds))), $"continuous controls fit at {size.Width}x{size.Height}");
                    using var preview = new Bitmap(form.Width, form.Height);
                    form.DrawToBitmap(preview, new Rectangle(System.Drawing.Point.Empty, form.Size));
                    preview.Save(Path.Combine(AppContext.BaseDirectory, $"moving-inspection-{size.Width}.png"));
                }
                Console.WriteLine("ALL MOVING-INSPECTION CHECKS PASSED; no physical COM port or motor used.");
            }
            catch (Exception ex) { Console.Error.WriteLine(ex); Environment.ExitCode = 1; }
            finally { Call(form, "DisconnectCamera"); form.Close(); }
        };
        Application.Run(form);
    }

    private sealed class MutableFeed(byte[] image) : ICameraFeed
    {
        private long _sequence;
        public byte[] Image { get; set; } = image;
        public string? Error => null;
        public CameraFrame Latest => new(Image, ++_sequence, DateTime.UtcNow);
        public Task Completion => Task.CompletedTask;
        public void Dispose() { }
    }
    private sealed class TestConveyor : IConveyorController
    {
        public bool IsRunning { get; private set; }
        public int RunCount { get; private set; }
        public int StopCount { get; private set; }
        public Task RunAsync() { RunCount++; IsRunning = true; return Task.CompletedTask; }
        public Task StopAsync() { StopCount++; IsRunning = false; return Task.CompletedTask; }
        public Task PingAsync() => Task.CompletedTask;
        public void Dispose() { IsRunning = false; }
    }
}
