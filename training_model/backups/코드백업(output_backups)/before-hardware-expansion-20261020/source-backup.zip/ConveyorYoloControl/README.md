# Mega 2560 컨베이어 + SZH-LD088 조명

## 연결

- 컨베이어 드라이버: PUL D5, DIR D6. 반주기 100µs로 조정해 기존 80µs 대비 이론상 속도를 약 20% 낮췄다. 실제 속도는 루프 처리 시간과 모터 조건에 따라 달라진다.
- SZH-LD088: WS2812B RGB LED 24개.
- D7 → 330Ω 저항 → 모듈 DIN/IN. DOUT/OUT에 연결하지 않는다.
- 모듈 5V → 안정된 외부 5V 전원. GND → 전원 GND와 Mega GND 공통 연결.
- D7은 데이터 출력이다. LED 전원은 D7에서 공급하지 않는다.
- 최대 밝기 흰색의 설계상 최대 전류는 24 × 60mA = 약 1.44A이므로 외부 5V 2A 이상 전원을 권장한다. 모터 전원을 LED에 연결하지 않는다.

## 동작

- 부팅 시 LED 24개를 흰색으로 켠다. 기본 밝기는 64/255(약 25%)이며 `LED_BRIGHTNESS`로 조정한다.
- LED 데이터를 부팅/수동 조명 변경 시에만 전송한다. 매 반복이나 PING마다 다시 전송하지 않는다.
- WS2812B 프레임 전송 중에는 약 0.72ms 동안 소프트웨어 모터 펄스에 짧은 간격 변화가 생길 수 있다. 지속 점등 중에는 재전송하지 않는다.
- 벨트 RUN/STOP, 검사 시작·중지, 통신 타임아웃으로 조명 상태를 바꾸지 않는다.
- 시리얼 연결로 보드가 재부팅되면 기본값인 흰색 켜짐으로 돌아간다.

## 사용자 앱

1. 최신 사용자 앱을 다시 실행한다.
2. **아두이노 설정·업로드 → COM 선택 → 업로드·연결**을 한 번 수행한다.
3. 별도 조명 줄의 **조명 끄기 (D7)** 또는 **조명 켜기 (D7)** 버튼으로 제어한다. 검사·벨트 구동 전에도 누를 수 있다.
4. **벨트 구동**은 별도 버튼으로 동작한다.

아두이노 미연결 상태에서 조명 버튼을 누르면 먼저 연결한다. COM 포트가 하나면 자동 선택하고 여러 개면 사용자가 선택한다. 조명 전용 연결은 RUN/STOP 명령을 보내지 않는다. 단, 첫 USB 시리얼 연결 시 보드 자체가 리셋될 수 있다.

기존 펌웨어로도 벨트 연결은 가능하다. 조명 명령을 지원하지 않으면 새 펌웨어 업로드 안내를 표시한다. 조명 제어에는 USB 연결과 새 펌웨어가 필요하다.

## 시리얼 명령 (9600 baud, 줄바꿈)

| 명령 | 응답 | 동작 |
|---|---|---|
| LED_ON | LED_ON | 흰색 점등 |
| LED_OFF | LED_OFF | 소등 |
| LED_STATUS | LED_ON 또는 LED_OFF | 조명 상태 조회 |
| RUN / STOP / PING / HELLO | 기존 응답 | 기존 컨베이어 제어 |

## 포함 라이브러리

공식 [Adafruit NeoPixel 1.12.5](https://github.com/adafruit/Adafruit_NeoPixel/tree/1.12.5)의 `Adafruit_NeoPixel.h`, `Adafruit_NeoPixel.cpp`와 `COPYING`을 포함했다. LGPL-3.0-or-later이며 원본 저작권·라이선스를 유지한다. IDE에서는 이 폴더의 `.ino`를 열고 함께 있는 `.h`와 `.cpp`도 유지한다. 앱 업로드 도구는 이 폴더 전체를 복사해 컴파일한다.

연결·전원 근거: [Adafruit 기본 연결](https://learn.adafruit.com/adafruit-neopixel-uberguide/basic-connections), [전원 설계](https://learn.adafruit.com/adafruit-neopixel-uberguide/powering-neopixels).

실제 장비에 자동 업로드하지 않고 Mega 2560 컴파일 및 모의 시리얼 제어를 확인했다.
