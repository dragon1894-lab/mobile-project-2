// PUL/DIR driver: PUL 5, DIR 6; 100 us half-pulse slows nominal speed by 20% from 80 us.
// USB serial 9600 baud. Starts stopped; RUN must be requested explicitly.
#include <string.h>
#include "Adafruit_NeoPixel.h"
const int PUL_PIN = 5;
const int DIR_PIN = 6;
const int LED_PIN = 7; // SZH-LD088 DIN (not its power supply)
const int LED_COUNT = 24;
const byte LED_BRIGHTNESS = 64; // 25%; white R=G=B
Adafruit_NeoPixel inspectionLight(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);
bool lightOn = true;
const unsigned int PULSE_DELAY = 100; // nominal microseconds per half pulse (previous: 80)
const unsigned long PC_TIMEOUT_MS = 3000;

bool conveyorRunning = false;
unsigned long lastPcMessage = 0;
char commandBuffer[32];
byte commandLength = 0;
bool commandOverflow = false;

void conveyorForward() {
  digitalWrite(DIR_PIN, LOW);
  conveyorRunning = true;
}

void conveyorStop() {
  conveyorRunning = false;
  digitalWrite(PUL_PIN, HIGH); // same idle level as the original sketch
}

void printState() {
  Serial.println(conveyorRunning ? "RUNNING" : "STOPPED");
}

void printLightState() {
  Serial.println(lightOn ? "LED_ON" : "LED_OFF");
}

void setLight(bool enabled) {
  lightOn = enabled;
  inspectionLight.fill(enabled ? inspectionLight.Color(255, 255, 255) : 0);
  // Update only on boot or manual change, never on each motor pulse.
  inspectionLight.show();
}

void handleCommand() {
  commandBuffer[commandLength] = '\0';
  if (strcmp(commandBuffer, "STOP") == 0) {
    conveyorStop();
    lastPcMessage = millis();
    printState();
  } else if (strcmp(commandBuffer, "RUN") == 0) {
    lastPcMessage = millis();
    conveyorForward();
    printState();
  } else if (strcmp(commandBuffer, "PING") == 0) {
    lastPcMessage = millis();
    printState();
  } else if (strcmp(commandBuffer, "HELLO") == 0) {
    lastPcMessage = millis();
    Serial.print("PL_CONVEYOR_PUL_DIR_V3 ");
    printState();
  } else if (strcmp(commandBuffer, "LED_ON") == 0) {
    lastPcMessage = millis();
    setLight(true);
    printLightState();
  } else if (strcmp(commandBuffer, "LED_OFF") == 0) {
    lastPcMessage = millis();
    setLight(false);
    printLightState();
  } else if (strcmp(commandBuffer, "LED_STATUS") == 0) {
    lastPcMessage = millis();
    printLightState();
  } else {
    Serial.println("ERROR UNKNOWN_COMMAND");
  }
}

void setup() {
  pinMode(PUL_PIN, OUTPUT);
  pinMode(DIR_PIN, OUTPUT);
  digitalWrite(DIR_PIN, LOW);
  conveyorStop();
  Serial.begin(9600);
  inspectionLight.begin();
  inspectionLight.setBrightness(LED_BRIGHTNESS);
  setLight(true);
  lastPcMessage = millis();
  Serial.println("PL_CONVEYOR_PUL_DIR_V3 STOPPED");
}

void loop() {
  // Bounded serial work prevents a byte stream starving pulses/watchdog.
  for (byte count = 0; count < 16 && Serial.available() > 0; ++count) {
    char value = (char)Serial.read();
    if (value == '\r') continue;
    if (value == '\n') {
      if (commandOverflow) Serial.println("ERROR COMMAND_TOO_LONG");
      else if (commandLength > 0) handleCommand();
      commandLength = 0;
      commandOverflow = false;
    } else if (commandLength < sizeof(commandBuffer) - 1) {
      commandBuffer[commandLength++] = value;
    } else {
      commandOverflow = true;
    }
  }
  if (conveyorRunning && (unsigned long)(millis() - lastPcMessage) >= PC_TIMEOUT_MS) {
    conveyorStop();
    Serial.println("WATCHDOG_STOP");
  }
  if (conveyorRunning) {
    // One pulse per loop; no blocking 5-second run or 3-second stop.
    digitalWrite(PUL_PIN, LOW);
    delayMicroseconds(PULSE_DELAY);
    digitalWrite(PUL_PIN, HIGH);
    delayMicroseconds(PULSE_DELAY);
  }
}
