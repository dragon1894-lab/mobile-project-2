// PUL/DIR driver: matches the user's working pulse sketch (pins 2/3).
// USB serial 9600 baud. Starts stopped; RUN must be requested explicitly.
#include <string.h>
const int PUL_PIN = 2;
const int DIR_PIN = 3;
// Diagnostic starting settings; actual speed depends on motor/driver gearing.
const unsigned int PULSE_DELAY = 500;       // target half period, nominal 1000 pulses/s
const unsigned int START_PULSE_DELAY = 2000; // start slower, nominal 250 pulses/s
const unsigned long START_RAMP_MS = 1000;
const unsigned long PC_TIMEOUT_MS = 3000;

bool conveyorRunning = false;
unsigned long runStartedAt = 0;
unsigned long lastPcMessage = 0;
char commandBuffer[32];
byte commandLength = 0;
bool commandOverflow = false;

void conveyorForward() {
  digitalWrite(DIR_PIN, LOW);
  if (!conveyorRunning) runStartedAt = millis();
  conveyorRunning = true;
}

unsigned int pulseDelayUs() {
  unsigned long elapsed = (unsigned long)(millis() - runStartedAt);
  if (elapsed >= START_RAMP_MS) return PULSE_DELAY;
  return START_PULSE_DELAY - (unsigned long)(START_PULSE_DELAY - PULSE_DELAY) * elapsed / START_RAMP_MS;
}

void conveyorStop() {
  conveyorRunning = false;
  digitalWrite(PUL_PIN, HIGH); // same idle level as the original sketch
}

void printState() {
  Serial.println(conveyorRunning ? "RUNNING" : "STOPPED");
}

void handleCommand() {
  commandBuffer[commandLength] = '\0';
  if (strcmp(commandBuffer, "STOP") == 0) {
    conveyorStop();
    lastPcMessage = millis();
    printState();
  } else if (strcmp(commandBuffer, "RUN") == 0) {
    lastPcMessage = millis();
    conveyorForward();
    printState();
  } else if (strcmp(commandBuffer, "PING") == 0) {
    lastPcMessage = millis();
    printState();
  } else if (strcmp(commandBuffer, "HELLO") == 0) {
    lastPcMessage = millis();
    Serial.print("PL_CONVEYOR_PUL_DIR_V2 ");
    printState();
  } else {
    Serial.println("ERROR UNKNOWN_COMMAND");
  }
}

void setup() {
  pinMode(PUL_PIN, OUTPUT);
  pinMode(DIR_PIN, OUTPUT);
  digitalWrite(DIR_PIN, LOW);
  conveyorStop();
  Serial.begin(9600);
  lastPcMessage = millis();
  Serial.println("PL_CONVEYOR_PUL_DIR_V2 STOPPED");
}

void loop() {
  // Bounded serial work prevents a byte stream starving pulses/watchdog.
  for (byte count = 0; count < 16 && Serial.available() > 0; ++count) {
    char value = (char)Serial.read();
    if (value == '\r') continue;
    if (value == '\n') {
      if (commandOverflow) Serial.println("ERROR COMMAND_TOO_LONG");
      else if (commandLength > 0) handleCommand();
      commandLength = 0;
      commandOverflow = false;
    } else if (commandLength < sizeof(commandBuffer) - 1) {
      commandBuffer[commandLength++] = value;
    } else {
      commandOverflow = true;
    }
  }
  if (conveyorRunning && (unsigned long)(millis() - lastPcMessage) >= PC_TIMEOUT_MS) {
    conveyorStop();
    Serial.println("WATCHDOG_STOP");
  }
  if (conveyorRunning) {
    // One pulse per loop; no blocking 5-second run or 3-second stop.
    unsigned int pulseDelay = pulseDelayUs();
    digitalWrite(PUL_PIN, LOW);
    delayMicroseconds(pulseDelay);
    digitalWrite(PUL_PIN, HIGH);
    delayMicroseconds(pulseDelay);
  }
}
