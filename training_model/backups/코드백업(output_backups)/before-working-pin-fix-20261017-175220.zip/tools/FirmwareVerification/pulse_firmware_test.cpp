// Host-only firmware logic check. Does not open serial ports or drive pins.
#include <deque>
#include <string>
#include <vector>
#include <iostream>
#include <stdexcept>
using byte = unsigned char;
const int OUTPUT = 1, HIGH = 1, LOW = 0;
unsigned long fakeMillis = 0;
unsigned long millis() { return fakeMillis; }
int levels[16] = {};
int lowPulseWrites = 0;
std::vector<int> delays;
void pinMode(int, int) {}
void digitalWrite(int pin, int value) { levels[pin] = value; if (pin == 2 && value == LOW) lowPulseWrites++; }
void delayMicroseconds(int us) { delays.push_back(us); }
struct FakeSerial {
    std::deque<char> incoming;
    std::vector<std::string> replies;
    std::string line;
    void begin(int baud) { if (baud != 9600) throw std::runtime_error("baud"); }
    int available() { return (int)incoming.size(); }
    int read() { auto c = incoming.front(); incoming.pop_front(); return c; }
    void print(const char* value) { line += value; }
    void println(const char* value) { line += value; replies.push_back(line); line.clear(); }
    void send(const std::string& value) { for (char c : value) incoming.push_back(c); }
} Serial;
#include "../../hardware/ConveyorYoloControl/ConveyorYoloControl.ino"

int checks = 0;
void check(bool value, const char* message) {
    if (!value) throw std::runtime_error(message);
    ++checks; std::cout << "PASS: " << message << '\n';
}
void send(const std::string& command) {
    Serial.send(command + "\n");
    while (Serial.available()) loop();
}
int main() {
    try {
        setup();
        check(!conveyorRunning && levels[2] == HIGH && levels[3] == LOW, "boot starts stopped at original pin levels");
        check(Serial.replies.back() == "PL_CONVEYOR_PUL_DIR_V2 STOPPED", "pulse firmware advertises distinct identity");
        send("HELLO"); send("PING");
        check(!conveyorRunning && lowPulseWrites == 0, "handshake and heartbeat never start motor");
        send("RUN");
        check(conveyorRunning && Serial.replies.back() == "RUNNING", "RUN enables pulse output and acknowledges");
        auto before = lowPulseWrites;
        for (int i = 0; i < 5; ++i) loop();
        check(lowPulseWrites == before + 5, "running loop produces pulses");
        check(delays.size() >= 10 && delays.back() == START_PULSE_DELAY && levels[3] == LOW, "motor starts with configured slower pulses and original direction");
        fakeMillis = runStartedAt + START_RAMP_MS / 2;
        check(pulseDelayUs() < START_PULSE_DELAY && pulseDelayUs() > PULSE_DELAY, "startup ramp changes pulse rate gradually");
        fakeMillis = runStartedAt + START_RAMP_MS;
        loop();
        check(delays.back() == PULSE_DELAY, "steady operation reaches configured constant target pulse delay");
        fakeMillis += 100;
        send("RUN");
        check(pulseDelayUs() == PULSE_DELAY, "duplicate RUN does not restart the acceleration ramp");
        send("STOP"); before = lowPulseWrites;
        for (int i = 0; i < 100; ++i) loop();
        check(!conveyorRunning && levels[2] == HIGH && lowPulseWrites == before && Serial.replies.back() == "STOPPED", "STOP halts pulses and holds idle level");
        send("RUN"); fakeMillis = lastPcMessage + 2999; loop();
        check(conveyorRunning, "watchdog allows valid heartbeat interval");
        fakeMillis = lastPcMessage + 3000; before = lowPulseWrites; loop();
        check(!conveyorRunning && lowPulseWrites == before && Serial.replies.back() == "WATCHDOG_STOP", "3-second watchdog stops before another pulse");
        send("PING");
        check(!conveyorRunning && Serial.replies.back() == "STOPPED", "heartbeat after timeout cannot restart motor");
        send("UNSUPPORTED");
        check(!conveyorRunning && Serial.replies.back() == "ERROR UNKNOWN_COMMAND", "unknown command cannot start motor");
        send(std::string(50, 'X'));
        check(!conveyorRunning && Serial.replies.back() == "ERROR COMMAND_TOO_LONG", "long commands rejected without motion");
        Serial.send("RU"); loop();
        check(!conveyorRunning, "partial command does not start motor");
        Serial.send("N\r\n"); loop();
        check(conveyorRunning, "fragmented CRLF command parsed correctly");
        send("STOP");
        fakeMillis = 0xfffffff0UL; send("RUN"); fakeMillis = 0x00000ba8UL; loop();
        check(!conveyorRunning, "watchdog handles unsigned millis rollover");
        std::cout << checks << " FIRMWARE HOST CHECKS PASSED\n";
    } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
