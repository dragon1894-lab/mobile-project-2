# 4번 - 아이폰 영상처리

현재 배포 모델은 `휴대폰_YOLO_CSharp_공유용.zip`의 **휴대폰 전체 위치 검출 모델**입니다. 입력 416×416, 출력 `[1,5,3549]`, 클래스는 `phone` 1개이며 기본 신뢰도 기준은 50%입니다. 실제 샘플에서 신뢰도 87.4%의 휴대폰 검출을 확인했습니다. 이는 해당 사진의 검출 신뢰도이며 전체 정확도는 아닙니다.

기종·색상·표면 깨짐 판정은 현재 모델에 포함되어 있지 않습니다. 휴대폰 위치 검출은 완료로 표시하고, 품질 판정은 `Undetermined`로 기록하여 정상·불량 개수를 늘리지 않습니다. 정상·불량 검사를 다시 사용하려면 아래 세 클래스로 학습한 모델이 필요합니다. C# 코드는 ONNX 메타데이터에서 클래스 수와 순서를 읽어 두 형식을 모두 지원합니다.

- `target_iphone`: 목표 아이폰
- `other_phone`: 목표 기종이 아닌 휴대폰
- `crack`: 표면 깨짐

## 모델 위치

학습 도구가 만든 모델을 다음 위치에 둡니다.

```text
04_Vision/models/best.onnx
```

빌드하면 모델이 실행 폴더의 `Models/best.onnx`로 자동 복사됩니다.

## 단독 테스트

Visual Studio에서 `ProductionLine.Vision.Tester`를 시작 프로젝트로 설정하고 실행합니다.
기본 샘플을 검사한 뒤 `04_Vision/output/iphone_result.jpg`에 검출 박스를 저장합니다.

명령줄에서 사진과 모델을 직접 지정할 수도 있습니다.

```text
ProductionLine.Vision.Tester.exe "사진.jpg" "best.onnx" 0.25
```

세 번째 값은 신뢰도 기준이며 기본값은 `0.5`입니다. 공유 파일의 시연 설정과 동일하게 신뢰도 50%, NMS IoU 0.45를 사용합니다. 원본 안내에 따르면 1장의 사진을 변형한 100장으로 만든 시연용 모델이므로 실제 컨베이어 영상에서도 확인해야 합니다.

## C# 호출 방법

```csharp
using var inspector = new YoloOnnxInspector();
var result = inspector.Inspect(imageBytes);
```

카메라 반복 검사에서는 `YoloOnnxInspector`를 한 번 만들고 계속 재사용해야 합니다. 매 프레임마다 생성하면 ONNX 모델을 반복해서 읽어 속도가 크게 느려집니다.

기존 `OpenCvSharpFrameAnalyzer`는 이전 화장품 뚜껑 검사 코드로 남겨 두었습니다. 사용자 화면과 서버를 아이폰 검사로 전환할 때는 `YoloOnnxInspector` 결과를 연결합니다.
