// Arduino Mega · 기존 모터드라이버 2/3번 핀 · 속도 250
// PC 사용자 앱: 9600 baud, 줄바꿈(\n) 명령. 적외선 센서는 사용하지 않습니다.
#include <string.h>
#define CONV_IN1 2
#define CONV_IN2 3
const int CONVEYOR_SPEED = 250;
const unsigned long PC_TIMEOUT_MS = 3000;

bool conveyorRunning = false;
unsigned long lastPcMessage = 0;
char commandBuffer[32];
byte commandLength = 0;
bool commandOverflow = false;

void conveyorForward() {
  analogWrite(CONV_IN1, CONVEYOR_SPEED);
  analogWrite(CONV_IN2, 0);
  conveyorRunning = true;
}

void conveyorStop() {
  analogWrite(CONV_IN1, 0);
  analogWrite(CONV_IN2, 0);
  conveyorRunning = false;
}

void printState() {
  Serial.println(conveyorRunning ? "RUNNING" : "STOPPED");
}

void handleCommand() {
  commandBuffer[commandLength] = '\0';
  if (strcmp(commandBuffer, "STOP") == 0) {
    conveyorStop();
    lastPcMessage = millis();
    printState();
  } else if (strcmp(commandBuffer, "RUN") == 0) {
    lastPcMessage = millis();
    conveyorForward();
    printState();
  } else if (strcmp(commandBuffer, "PING") == 0) {
    lastPcMessage = millis();
    printState();
  } else if (strcmp(commandBuffer, "HELLO") == 0) {
    lastPcMessage = millis();
    Serial.print("PL_CONVEYOR_V1 ");
    printState();
  } else {
    Serial.println("ERROR UNKNOWN_COMMAND");
  }
}

void setup() {
  pinMode(CONV_IN1, OUTPUT);
  pinMode(CONV_IN2, OUTPUT);
  conveyorStop();
  Serial.begin(9600);
  lastPcMessage = millis();
  Serial.println("PL_CONVEYOR_V1 STOPPED");
}

void loop() {
  while (Serial.available() > 0) {
    char value = (char)Serial.read();
    if (value == '\r') continue;
    if (value == '\n') {
      if (commandOverflow) Serial.println("ERROR COMMAND_TOO_LONG");
      else if (commandLength > 0) handleCommand();
      commandLength = 0;
      commandOverflow = false;
    } else if (commandLength < sizeof(commandBuffer) - 1) {
      commandBuffer[commandLength++] = value;
    } else {
      commandOverflow = true;
    }
  }
  if (conveyorRunning && (unsigned long)(millis() - lastPcMessage) >= PC_TIMEOUT_MS) {
    conveyorStop();
    Serial.println("WATCHDOG_STOP");
  }
}
