using ProductionLine.Shared;
using ProductionLine.Vision;

namespace ProductionLine.UserApp;

public sealed partial class UserMainForm
{
    private ICameraFeed? _camera;
    private Task _cameraClosed = Task.CompletedTask;
    private readonly NumericUpDown _cameraIndex = new() { Minimum = 0, Maximum = 9, Width = 55 };
    private readonly Button _cameraConnect = new() { Text = "카메라 연결", AutoSize = true };
    private readonly Button _inspectionStart = new() { Text = "검사 시작", AutoSize = true };
    private readonly Label _inspectionState = new() { AutoSize = true, Text = "검사 대기 · 카메라 연결 후 YOLO 모델을 확인하세요.", Padding = new Padding(8) };
    private const int InspectionIntervalMs = 100;
    private readonly System.Windows.Forms.Timer _inspectionTimer = new() { Interval = InspectionIntervalMs };
    private YoloOnnxInspector? _yoloInspector;
    private string? _selectedYoloModelPath;
    private const float PhoneConfidenceThreshold = 0.5f;
    private long _displayedFrame, _inspectedFrame;
    private bool _runningInspection, _inspectionBusy;
    private bool _productPresent;
    private DateTime _lastProductSeenUtc;
    private int _inspectionGeneration;

    private Control CameraControls()
    {
        var container = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 6, ColumnCount = 1 };
        container.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        container.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        container.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        container.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        container.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
        container.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, Margin = Padding.Empty };
        buttons.Controls.Add(new Label { Text = "카메라 번호", AutoSize = true, Padding = new Padding(0, 5, 0, 0) });
        buttons.Controls.Add(_cameraIndex);
        buttons.Controls.Add(_cameraConnect);
        buttons.Controls.Add(Button("연결 해제", DisconnectCamera));
        buttons.Controls.Add(_inspectionStart);
        buttons.Controls.Add(Button("검사 중지", () => StopInspection("검사 중지 · 전송 중인 1건은 완료될 수 있습니다.")));
        var models = new FlowLayoutPanel { Dock = DockStyle.Fill, Margin = Padding.Empty };
        models.Controls.Add(Button("YOLO 모델 확인", CheckYoloModel));
        models.Controls.Add(Button("YOLO 모델 선택", SelectYoloModel));
        models.Controls.Add(_arduinoSetup);
        models.Controls.Add(new Label { Text = "모델 변경은 검사 중지 후 가능합니다.", AutoSize = true, Padding = new Padding(8) });
        container.Controls.Add(buttons, 0, 0);
        container.Controls.Add(models, 0, 1);
        container.Controls.Add(BuildConveyorControls(), 0, 2);
        container.Controls.Add(BuildVerificationControls(), 0, 3);
        container.Controls.Add(_conveyorState, 0, 4);
        container.Controls.Add(_inspectionState, 0, 5);
        _cameraConnect.Click += (_, _) => ConnectCamera();
        _inspectionStart.Click += async (_, _) => await StartInspectionAsync();
        _inspectionTimer.Tick += async (_, _) => await InspectCameraAsync();
        return container;
    }

    private void ConnectCamera()
    {
        if (_camera != null) return;
        if (!_cameraClosed.IsCompleted) { _videoStatus.Text = "이전 카메라 연결을 해제하는 중입니다. 잠시 후 다시 연결하세요."; return; }
        _displayedFrame = _inspectedFrame = 0;
        _productPresent = false;
        _lastProductSeenUtc = default;
        _camera = new CameraSession((int)_cameraIndex.Value);
        _cameraConnect.Enabled = false; _cameraIndex.Enabled = false;
        _videoStatus.Text = "카메라 연결 중...";
        _frames.Interval = 50;
    }

    private void DisconnectCamera()
    {
        StopInspection("검사 대기 · 카메라를 다시 연결하세요.");
        var old = _camera; _camera = null;
        if (old != null) { old.Dispose(); _cameraClosed = old.Completion; }
        _productPresent = false;
        _lastProductSeenUtc = default;
        _cameraConnect.Enabled = true; _cameraIndex.Enabled = true;
        _video.Image?.Dispose(); _video.Image = null;
        _videoStatus.Text = "카메라 연결 해제됨";
        _frames.Interval = 500;
    }

    private void DisplayCameraFrame()
    {
        if (_camera == null) return;
        if (_camera.Error is string error)
        {
            DisconnectCamera(); _videoStatus.Text = error; return;
        }
        var frame = _camera.Latest;
        if (frame == null) return;
        if ((DateTime.UtcNow - frame.ReceivedUtc).TotalSeconds > 3)
        {
            StopInspection("영상 수신 지연으로 검사 중지");
            _videoStatus.Text = "카메라 영상이 3초 이상 갱신되지 않았습니다."; return;
        }
        // 검사 중에는 YOLO 결과 프레임을 표시합니다. 원본 영상이 박스를 덮어쓰지 않게 합니다.
        if (_runningInspection) return;
        if (frame.Sequence == _displayedFrame) return;
        using var stream = new MemoryStream(frame.Jpeg);
        using var source = Image.FromStream(stream);
        var old = _video.Image; _video.Image = new Bitmap(source); old?.Dispose();
        _displayedFrame = frame.Sequence;
        _videoStatus.Text = $"카메라 {_cameraIndex.Value} 연결됨 · {frame.ReceivedUtc.ToLocalTime():HH:mm:ss} · 프레임 {frame.Sequence}";
    }

    private void CheckYoloModel()
    {
        try
        {
            EnsureYoloInspector();
            _inspectionState.Text = $"YOLO 모델 준비 완료 · 신뢰도 {PhoneConfidenceThreshold:P0} · {_yoloInspector!.CapabilityDescription} · 클래스: {string.Join(", ", _yoloInspector.ClassNames)}";
        }
        catch (Exception ex)
        {
            _inspectionState.Text = "YOLO 모델 준비 실패: " + ex.Message;
        }
    }

    private void SelectYoloModel()
    {
        if (_runningInspection || _inspectionBusy || _verificationHold || _arduinoSetupBusy)
        { _inspectionState.Text = "검사를 중지한 후 모델을 선택하세요."; return; }
        using var dialog = new OpenFileDialog
        {
            Title = "검사에 사용할 YOLO ONNX 모델 선택",
            Filter = "YOLO ONNX 모델 (*.onnx)|*.onnx",
            InitialDirectory = Path.Combine(AppContext.BaseDirectory, "Models")
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try { LoadYoloModel(dialog.FileName); CheckYoloModel(); }
        catch (Exception ex) { _inspectionState.Text = "모델 선택 실패 · 기존 모델 유지: " + ex.Message; }
    }

    private void LoadYoloModel(string modelPath)
    {
        if (_runningInspection || _inspectionBusy || _verificationHold || _arduinoSetupBusy)
            throw new InvalidOperationException("검사를 중지한 후 모델을 변경하세요.");
        var next = new YoloOnnxInspector(modelPath, PhoneConfidenceThreshold);
        var old = _yoloInspector;
        _yoloInspector = next;
        _selectedYoloModelPath = next.ModelPath;
        old?.Dispose();
        _productPresent = false;
        _lastProductSeenUtc = default;
        _inspectedFrame = 0;
    }

    private async Task StartInspectionAsync()
    {
        if (_runningInspection || _inspectionBusy || _arduinoSetupBusy) return;
        if (_verificationHold && _verificationCompleted)
        { _inspectionState.Text = "검사 완료·해제 버튼을 먼저 누르세요."; return; }
        if (_verificationHold && _conveyor is not { IsRunning: false })
        { _inspectionState.Text = "검사 재시도 전에 아두이노를 연결하여 정지 응답을 확인하세요."; return; }
        if (_camera?.Latest == null)
        { _inspectionState.Text = "먼저 카메라를 연결하세요."; return; }
        if (_lines.SelectedItem is not LineStatusDto { IsReal: true })
        { _inspectionState.Text = "실제 검사 가능한 라인을 선택하세요."; return; }
        try { EnsureYoloInspector(); }
        catch (Exception ex) { _inspectionState.Text = "YOLO 모델 준비 실패: " + ex.Message; return; }
        _runningInspection = true; _inspectionStart.Enabled = false;
        if (!_awaitingProductExit) { _productPresent = false; _lastProductSeenUtc = default; }
        _inspectionGeneration++;
        _inspectionState.Text = "YOLO 연속 검사 중 · 목표 간격 0.1초 · 제품별 기록은 한 번 저장";
        _inspectionTimer.Start();
        await InspectCameraAsync();
    }

    private void StopInspection(string message)
    {
        _runningInspection = false; _inspectionGeneration++;
        _inspectionTimer.Stop(); _inspectionStart.Enabled = !_inspectionBusy;
        _inspectionState.Text = message;
        if (_stopOnPhone.Checked && _conveyor is { IsRunning: true })
            _ = StopConveyorWhenInspectionStopsAsync();
    }

    private async Task InspectCameraAsync()
    {
        if (!_runningInspection || _inspectionBusy || (_verificationHold && _verificationCompleted)) return;
        var frame = _camera?.Latest;
        if (frame == null || (DateTime.UtcNow - frame.ReceivedUtc).TotalSeconds > 3)
        { StopInspection("영상이 없어 검사를 중지했습니다. 카메라 연결을 확인하세요."); return; }
        if (frame.Sequence == _inspectedFrame) return;
        _inspectedFrame = frame.Sequence;
        var line = _lineId;
        var generation = _inspectionGeneration;
        _inspectionBusy = true;
        try
        {
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            var analysis = await Task.Run(() => _yoloInspector!.Inspect(frame.Jpeg));
            if (IsDisposed || !_runningInspection || generation != _inspectionGeneration) return;
            var verifyStopped = _verificationHold || await StopOnPhoneAsync(analysis);
            if (verifyStopped)
            {
                frame = await WaitForStoppedFrameAsync(frame.Sequence, generation);
                _inspectedFrame = frame.Sequence;
                analysis = await Task.Run(() => _yoloInspector!.Inspect(frame.Jpeg));
                if (IsDisposed || !_runningInspection || generation != _inspectionGeneration) return;
                if (!analysis.Detections.Any(value => YoloOnnxInspector.IsPhoneClass(value.ClassName)))
                    throw new InvalidOperationException("정지 후 영상에서 휴대폰을 확인하지 못했습니다. 위치를 확인하고 검사 재시도를 누르세요.");
            }
            stopwatch.Stop();

            // 동일 제품도 매 프레임 표시를 갱신하고, 서버 저장에만 중복 방지를 적용합니다.
            ShowYoloResultImage(analysis.ResultImage);
            _displayedFrame = frame.Sequence;
            var confidence = analysis.Detections.Select(value => value.Confidence).DefaultIfEmpty(0).Max();
            var detectionResult = analysis.ObjectFound && !_yoloInspector!.CanClassifyProducts ? "휴대폰 검출 완료 · 품질 판정 미지원" : ResultText(analysis.Result);
            _result.Text = $"YOLO 연속 검사: {detectionResult} · 최고 신뢰도 {confidence:P1}\r\n{analysis.Reason} · 촬영 {frame.ReceivedUtc.ToLocalTime():HH:mm:ss.fff}";
            _result.ForeColor = analysis.Result == InspectionResultType.Defect ? UserTheme.Red : UserTheme.Text;
            _videoStatus.Text = $"카메라 {_cameraIndex.Value} · YOLO 처리 {stopwatch.ElapsedMilliseconds}ms · 목표 간격 {InspectionIntervalMs}ms · 프레임 {frame.Sequence}";
            if (IsDisposed || !_runningInspection || generation != _inspectionGeneration) return;
            if (!analysis.ObjectFound)
            {
                if (_lastProductSeenUtc == default || (DateTime.UtcNow - _lastProductSeenUtc).TotalMilliseconds >= 250)
                { _productPresent = false; _awaitingProductExit = false; }
                _inspectionState.Text = "YOLO 연속 검사 중 · 목표 간격 0.1초 · 휴대폰 감지 대기";
                return;
            }

            _lastProductSeenUtc = DateTime.UtcNow;
            if (_awaitingProductExit)
            { _inspectionState.Text = "검사 완료한 제품의 이동 중 · 화면을 벗어나면 다음 제품 검출을 준비합니다."; return; }
            _inspectionState.Text = "YOLO 연속 검사 중 · 목표 간격 0.1초 · 같은 제품은 중복 집계하지 않습니다.";
            if (_productPresent && !verifyStopped) return;
            _productPresent = true;

            if (IsDisposed || !_runningInspection || generation != _inspectionGeneration) return;

            await _api.SaveCameraInspectionAsync(new CameraInspectionRequest(line, analysis.Result, analysis.Reason,
                confidence, _yoloInspector!.CanClassifyProducts));
            if (IsDisposed || generation != _inspectionGeneration) return;
            if (verifyStopped)
            {
                _verificationCompleted = true;
                _verificationAction.Text = "검사 완료·해제";
                _verificationAction.Enabled = true;
                _conveyorState.Text = "검사 및 서버 저장 완료 · 벨트 정지 유지 · 검사 완료·해제 후 벨트 구동을 누르세요.";
                _inspectionState.Text = $"정지 후 새 영상 검사 완료 · {detectionResult} · 기록 저장 {DateTime.Now:HH:mm:ss}";
            }
            else _inspectionState.Text = $"YOLO 연속 검사 중 · 목표 간격 0.1초 · 제품 기록 저장 {DateTime.Now:HH:mm:ss}";
            await RefreshAsync(false);
        }
        catch (Exception ex)
        {
            if (!IsDisposed)
            {
                StopInspection("검사 중지 · 분석/저장 실패: " + ex.Message + " · 자동 재전송하지 않습니다.");
                if (_verificationHold && !_verificationCompleted)
                {
                    _verificationAction.Text = "검사 재시도";
                    _verificationAction.Enabled = true;
                }
            }
        }
        finally
        {
            _inspectionBusy = false;
            if (!IsDisposed)
            {
                _inspectionStart.Enabled = !_runningInspection;
                _conveyorRun.Enabled = _conveyor != null && !_verificationHold && !_conveyorCommandBusy;
            }
            else _yoloInspector?.Dispose();
        }
    }

    private void EnsureYoloInspector()
    {
        _yoloInspector ??= new YoloOnnxInspector(_selectedYoloModelPath, PhoneConfidenceThreshold);
    }

    private void ShowYoloResultImage(byte[] imageBytes)
    {
        if (imageBytes.Length == 0) return;
        using var stream = new MemoryStream(imageBytes);
        using var source = Image.FromStream(stream);
        var old = _video.Image;
        _video.Image = new Bitmap(source);
        old?.Dispose();
    }
}
