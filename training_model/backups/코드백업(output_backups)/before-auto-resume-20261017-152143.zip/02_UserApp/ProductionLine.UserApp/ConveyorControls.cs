using ProductionLine.Vision;

namespace ProductionLine.UserApp;

public sealed partial class UserMainForm
{
    private IConveyorController? _conveyor;
    private readonly ComboBox _conveyorPort = new() { Width = 90, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly Button _conveyorConnect = new() { Text = "벨트 연결", AutoSize = true };
    private readonly Button _conveyorRun = new() { Text = "벨트 구동", AutoSize = true, Enabled = false };
    private readonly Button _conveyorStop = new() { Text = "벨트 정지", AutoSize = true, Enabled = false };
    private readonly CheckBox _stopOnPhone = new() { Text = "휴대폰 검출 시 정지", Checked = true, AutoSize = true };
    private readonly Label _conveyorState = new() { AutoSize = true, Text = "벨트 미연결 · 처음에는 아두이노 설정·업로드, 이후에는 COM 선택 후 벨트 연결을 누르세요." };
    private readonly System.Windows.Forms.Timer _conveyorHeartbeat = new() { Interval = 500 };
    private bool _conveyorCommandBusy;
    private bool _conveyorHeartbeatBusy;
    private readonly Button _verificationAction = new() { Text = "검사 완료·해제", AutoSize = true, Enabled = false };
    private readonly NumericUpDown _settleMilliseconds = new() { Minimum = 100, Maximum = 5000, Value = 500, Increment = 100, Width = 65 };
    private bool _verificationHold, _verificationCompleted, _awaitingProductExit;

    private Control BuildConveyorControls()
    {
        var controls = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, Margin = Padding.Empty };
        controls.Controls.Add(new Label { Text = "아두이노 COM", AutoSize = true, Padding = new Padding(0, 5, 0, 0) });
        controls.Controls.Add(_conveyorPort);
        controls.Controls.Add(Button("포트 갱신", RefreshConveyorPorts));
        controls.Controls.Add(_conveyorConnect);
        controls.Controls.Add(Button("벨트 연결 해제", async () => await DisconnectConveyorAsync()));
        controls.Controls.Add(_conveyorRun);
        controls.Controls.Add(_conveyorStop);
        controls.Controls.Add(_stopOnPhone);
        _arduinoSetup.Click += async (_, _) => await OpenArduinoSetupAsync();
        _verificationAction.Click += async (_, _) =>
        {
            if (_inspectionBusy || _conveyorCommandBusy) return;
            if (!_verificationCompleted) { await StartInspectionAsync(); return; }
            _verificationHold = _verificationCompleted = false;
            _awaitingProductExit = true;
            _verificationAction.Enabled = false;
            _conveyorState.Text = "검사 완료 해제 · 벨트 구동을 누르세요. 현재 제품이 화면을 벗어난 뒤 다음 제품을 감지합니다.";
            _conveyorRun.Enabled = _conveyor != null;
        };
        _conveyorConnect.Click += async (_, _) => await ConnectConveyorAsync();
        _conveyorRun.Click += async (_, _) => await RunConveyorAsync();
        _conveyorStop.Click += async (_, _) =>
        {
            try { await StopConveyorAsync("사용자 요청으로 벨트 정지 응답 확인"); }
            catch (Exception) { /* StopConveyorAsync에서 연결 오류를 표시합니다. */ }
        };
        _conveyorHeartbeat.Tick += async (_, _) => await PingConveyorAsync();
        RefreshConveyorPorts();
        return controls;
    }

    private Control BuildVerificationControls()
    {
        var controls = new FlowLayoutPanel { Dock = DockStyle.Fill, Margin = Padding.Empty };
        controls.Controls.Add(_verificationAction);
        controls.Controls.Add(new Label { Text = "정지 대기(ms)", AutoSize = true, Padding = new Padding(0, 5, 0, 0) });
        controls.Controls.Add(_settleMilliseconds);
        controls.Controls.Add(new Label { Text = "정지 후 새 영상 검사 → 결과 확인 → 완료·해제 → 수동 구동", AutoSize = true, Padding = new Padding(8) });
        return controls;
    }

    private void RefreshConveyorPorts()
    {
        if (_conveyor != null || _conveyorCommandBusy) return;
        try
        {
            var previous = _conveyorPort.SelectedItem as string ?? ArduinoPortSettings.Load();
            _conveyorPort.DataSource = ConveyorSerialController.GetPortNames();
            _conveyorPort.SelectedIndex = -1;
            if (previous != null && _conveyorPort.Items.Contains(previous)) _conveyorPort.SelectedItem = previous;
        }
        catch (Exception ex) { _conveyorState.Text = "COM 포트 조회 실패: " + ex.Message; }
    }

    private async Task ConnectConveyorAsync()
    {
        if (_conveyor != null || _conveyorCommandBusy) return;
        if (_conveyorPort.SelectedItem is not string port)
        { _conveyorState.Text = "Mega 2560의 USB를 연결하고 COM 포트를 선택하세요. 처음에는 아두이노 설정·업로드를 누르세요."; return; }
        _conveyorCommandBusy = true;
        _conveyorConnect.Enabled = _conveyorPort.Enabled = false;
        _conveyorState.Text = "아두이노 연결 확인 중...";
        try
        {
            var controller = await ConveyorSerialController.ConnectAsync(port);
            if (IsDisposed) { controller.Dispose(); return; }
            _conveyor = controller;
            ArduinoPortSettings.Save(port);
            _conveyorStop.Enabled = true;
            _conveyorRun.Enabled = !_verificationHold;
            _conveyorState.Text = $"{port} 연결됨 · 정지 확인 · 검사 시작 후 벨트 구동을 누르세요.";
            _conveyorHeartbeat.Start();
        }
        catch (Exception ex) { if (!IsDisposed) _conveyorState.Text = "벨트 연결 실패: " + ex.Message; }
        finally
        {
            _conveyorCommandBusy = false;
            if (!IsDisposed) _conveyorConnect.Enabled = _conveyorPort.Enabled = _conveyor == null;
        }
    }

    private async Task RunConveyorAsync()
    {
        if (_conveyor == null || _conveyorCommandBusy || _arduinoSetupBusy) return;
        if (_inspectionBusy || _verificationHold)
        { _conveyorState.Text = "검사 또는 저장 중에는 구동할 수 없습니다. 검사 완료·해제 후 다시 구동하세요."; return; }
        if (_stopOnPhone.Checked && !_runningInspection)
        { _conveyorState.Text = "검출 정지를 사용하려면 카메라 연결 후 검사 시작을 먼저 누르세요."; return; }
        _conveyorCommandBusy = true;
        _conveyorRun.Enabled = false;
        try
        {
            await _conveyor.RunAsync();
            if (!IsDisposed) _conveyorState.Text = _stopOnPhone.Checked
                ? "PUL/DIR 구동 응답 확인 · 휴대폰 검출 시 정지 · 검사 완료 후 수동 재구동"
                : "PUL/DIR 수동 구동 응답 확인 · 휴대폰 검출 정지 연동은 꺼져 있습니다.";
        }
        catch (Exception ex) { if (!IsDisposed) FailConveyor("구동 응답 확인 실패: " + ex.Message); }
        finally { _conveyorCommandBusy = false; if (!IsDisposed) _conveyorRun.Enabled = _conveyor != null && !_verificationHold && !_inspectionBusy; }
    }

    private async Task StopConveyorAsync(string message)
    {
        var controller = _conveyor;
        if (controller == null) return;
        try
        {
            await controller.StopAsync();
            if (!IsDisposed && ReferenceEquals(controller, _conveyor)) _conveyorState.Text = message;
        }
        catch (Exception ex)
        {
            if (!IsDisposed)
            {
                FailConveyor("벨트 정지 응답을 확인하지 못했습니다: " + ex.Message);
                StopInspection("정지 응답 확인 실패 · 벨트 실제 상태를 확인하세요.");
            }
            throw;
        }
    }

    private async Task<bool> StopOnPhoneAsync(YoloInspectionAnalysis analysis)
    {
        if (!_stopOnPhone.Checked || _awaitingProductExit || _conveyor is not { IsRunning: true }) return false;
        if (!analysis.Detections.Any(value => YoloOnnxInspector.IsPhoneClass(value.ClassName))) return false;
        _verificationHold = true;
        _verificationCompleted = false;
        _verificationAction.Enabled = _conveyorRun.Enabled = false;
        // 서버 저장·중복 집계 검사보다 먼저 정지 명령을 전달합니다.
        await StopConveyorAsync("휴대폰 검출 → 펄스 정지 응답 확인 · 정지 대기 후 새 영상으로 검사합니다.");
        return true;
    }

    private async Task<CameraFrame> WaitForStoppedFrameAsync(long detectedSequence, int generation)
    {
        var delay = (int)_settleMilliseconds.Value;
        _inspectionState.Text = $"벨트 정지 응답 확인 · {delay}ms 대기 후 새 영상으로 검사";
        await Task.Delay(delay);
        var notBefore = DateTime.UtcNow;
        var timeout = System.Diagnostics.Stopwatch.StartNew();
        while (timeout.ElapsedMilliseconds < 2500)
        {
            if (IsDisposed || !_runningInspection || generation != _inspectionGeneration)
                throw new OperationCanceledException("검사가 중단되었습니다. 벨트는 정지 상태를 유지합니다.");
            if (_conveyor is not { IsRunning: false })
                throw new IOException("벨트 연결 또는 정지 상태를 확인할 수 없습니다.");
            if (_camera?.Error is string error) throw new IOException(error);
            var frame = _camera?.Latest;
            if (frame != null && frame.Sequence > detectedSequence && frame.ReceivedUtc >= notBefore)
                return frame;
            await Task.Delay(20);
        }
        throw new TimeoutException("정지 후 새 카메라 영상을 받지 못했습니다. 벨트는 정지 상태를 유지합니다.");
    }

    private async Task PingConveyorAsync()
    {
        if (_conveyor == null || _conveyorHeartbeatBusy || _conveyorCommandBusy) return;
        var controller = _conveyor;
        _conveyorHeartbeatBusy = true;
        try { await controller.PingAsync(); }
        catch (Exception ex)
        {
            if (!IsDisposed && ReferenceEquals(controller, _conveyor))
            {
                FailConveyor("아두이노 통신 오류 · 통신 중단 3초 후 정지: " + ex.Message);
                StopInspection("벨트 통신 오류로 검사 중지");
            }
        }
        finally { _conveyorHeartbeatBusy = false; }
    }

    private async Task DisconnectConveyorAsync()
    {
        if (_conveyorCommandBusy || _conveyor == null) return;
        var controller = _conveyor;
        _conveyorCommandBusy = true;
        _conveyorHeartbeat.Stop();
        var confirmed = false;
        try { await StopConveyorAsync("벨트 정지 응답 확인"); confirmed = true; }
        catch (Exception) { /* 연결 해제 후에도 펌웨어 통신 타임아웃이 적용됩니다. */ }
        finally
        {
            controller.Dispose();
            _conveyor = null;
            _conveyorCommandBusy = false;
            if (!IsDisposed)
            {
                _conveyorRun.Enabled = _conveyorStop.Enabled = false;
                _conveyorConnect.Enabled = _conveyorPort.Enabled = true;
                _conveyorState.Text = confirmed ? "벨트 정지 응답 확인 후 연결 해제" : "벨트 연결 해제 · 정지 응답 미확인 · 실제 상태를 확인하세요.";
            }
        }
    }

    private void FailConveyor(string message)
    {
        _conveyorHeartbeat.Stop();
        _conveyor?.Dispose();
        _conveyor = null;
        _conveyorRun.Enabled = _conveyorStop.Enabled = false;
        _conveyorConnect.Enabled = _conveyorPort.Enabled = true;
        _conveyorState.Text = message;
    }

    private async Task StopConveyorWhenInspectionStopsAsync()
    {
        try { await StopConveyorAsync("검사 중지에 따라 벨트 정지 응답 확인"); }
        catch (Exception) { /* 오류는 정지 메서드에서 표시합니다. */ }
    }
}
