using System.Reflection;
using OpenCvSharp;
using ProductionLine.Shared;
using ProductionLine.UserApp;
using ProductionLine.Vision;

namespace ProductionLine.Verification;

internal static class ContinuousYoloChecks
{
    private const BindingFlags Flags = BindingFlags.Instance | BindingFlags.NonPublic;
    private static T Field<T>(object instance, string name) => (T)instance.GetType().GetField(name, Flags)!.GetValue(instance)!;
    private static void Set(object instance, string name, object value) => instance.GetType().GetField(name, Flags)!.SetValue(instance, value);
    private static object? Call(object instance, string name, params object[] args) => instance.GetType().GetMethod(name, Flags)!.Invoke(instance, args);
    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
        Console.WriteLine("PASS: " + message);
    }

    public static void Run()
    {
        Application.SetHighDpiMode(HighDpiMode.SystemAware);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        var imagePath = Environment.GetCommandLineArgs().Skip(2).FirstOrDefault()
            ?? throw new ArgumentException("Pass a phone sample image after --continuous-yolo.");
        var phone = File.ReadAllBytes(imagePath);
        using var blank = new Mat(1080, 1920, MatType.CV_8UC3, Scalar.Black);
        using var server = new TestServer();
        using var api = new ProductionLineApiClient(server.Url);
        api.LoginAsync("test", "test").GetAwaiter().GetResult();
        using var form = new UserMainForm(api);
        var feed = new MutableFeed(phone);
        var belt = new TestConveyor();
        form.Shown += async (_, _) =>
        {
            try
            {
                await ConveyorProtocolChecks.RunAsync();
                for (var i = 0; i < 200 && Field<bool>(form, "_loading"); i++) await Task.Delay(25);
                await (Task)Call(form, "RefreshAsync", false)!;
                Field<System.Windows.Forms.Timer>(form, "_refresh").Stop();
                Field<System.Windows.Forms.Timer>(form, "_frames").Stop();
                Set(form, "_camera", feed);
                Set(form, "_conveyor", belt);
                var activeModel = Path.Combine(AppContext.BaseDirectory, "Models", "best.onnx");
                var alternativeModel = Path.Combine(AppContext.BaseDirectory, "Models", "alternatives", "additional-three-class", "best.onnx");
                Call(form, "LoadYoloModel", alternativeModel);
                Check(Field<YoloOnnxInspector>(form, "_yoloInspector").ClassNames.Count == 3, "additional model remains selectable with pulse control");
                Call(form, "LoadYoloModel", activeModel);
                var selectedInspector = Field<YoloOnnxInspector>(form, "_yoloInspector");
                Check(selectedInspector.ClassNames.Count == 6, "six-class model remains the active default");
                try { Call(form, "LoadYoloModel", Path.Combine(AppContext.BaseDirectory, "missing.onnx")); }
                catch (TargetInvocationException ex) when (ex.InnerException is FileNotFoundException) { }
                Check(ReferenceEquals(selectedInspector, Field<YoloOnnxInspector>(form, "_yoloInspector")), "invalid model selection preserves the working model");
                Field<NumericUpDown>(form, "_settleMilliseconds").Value = 100;
                var start = (Task)Call(form, "StartInspectionAsync")!;
                Field<System.Windows.Forms.Timer>(form, "_inspectionTimer").Stop();
                await start;
                Check(Field<System.Windows.Forms.Timer>(form, "_inspectionTimer").Interval == 100, "continuous detection retains its 100ms target interval");
                Check(belt.StopCount == 1 && !belt.IsRunning, "actual ONNX phone detection requests STOP before recording");
                Check(feed.ReadCount >= 3, "verification obtains a new frame after stop and settling");
                Check(server.InspectionCount == 1 && Field<bool>(form, "_verificationCompleted"), "stopped-frame verification and server save complete");
                Check(server.LastCameraInspection is { ClassificationAvailable: false, Result: InspectionResultType.Undetermined, Confidence: >= 0.5 },
                    "stopped-frame result uses the camera API and preserves unclassified quality and confidence");
                Check(Field<bool>(form, "_verificationHold") && !Field<Button>(form, "_conveyorRun").Enabled, "completed inspection holds belt stopped until operator release");
                try { Call(form, "LoadYoloModel", alternativeModel); }
                catch (TargetInvocationException ex) when (ex.InnerException is InvalidOperationException) { }
                Check(ReferenceEquals(selectedInspector, Field<YoloOnnxInspector>(form, "_yoloInspector")), "active inspection prevents changing models");
                await (Task)Call(form, "RunConveyorAsync")!;
                Check(belt.RunCount == 0, "RUN is rejected while inspection hold is active");
                var reads = feed.ReadCount;
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(server.InspectionCount == 1 && feed.ReadCount == reads, "completed hold does not repeatedly inspect or record same product");
                Field<Button>(form, "_verificationAction").PerformClick();
                Check(!Field<bool>(form, "_verificationHold") && Field<bool>(form, "_awaitingProductExit"), "operator release waits for current product exit");
                await (Task)Call(form, "RunConveyorAsync")!;
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(belt.IsRunning && belt.StopCount == 1 && server.InspectionCount == 1, "released product can move away without immediate repeated STOP");
                feed.Image = blank.ToBytes(".jpg");
                await Task.Delay(300);
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(!Field<bool>(form, "_awaitingProductExit") && !Field<bool>(form, "_productPresent"), "empty belt rearms next product detection");
                await (Task)Call(form, "StopOnPhoneAsync", new YoloInspectionAnalysis(true, InspectionResultType.Defect, "crack only",
                    [new YoloDetection(2, YoloOnnxInspector.Crack, 0.9f, new(10, 10, 20, 20))], []))!;
                Check(belt.IsRunning, "crack-only detection does not count as whole-phone arrival");
                feed.Image = phone;
                server.Fail = true;
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(!belt.IsRunning && Field<bool>(form, "_verificationHold") && !Field<bool>(form, "_verificationCompleted"), "server failure preserves stop and does not mark verification complete");
                Check(server.InspectionCount == 1 && !Field<bool>(form, "_runningInspection"), "failed save does not publish a successful inspection");
                await (Task)Call(form, "RunConveyorAsync")!;
                Check(belt.RunCount == 1, "RUN remains blocked after failed verification");
                server.Fail = false;
                start = (Task)Call(form, "StartInspectionAsync")!;
                Field<System.Windows.Forms.Timer>(form, "_inspectionTimer").Stop();
                await start;
                Check(server.InspectionCount == 2 && Field<bool>(form, "_verificationCompleted") && belt.StopCount == 2,
                    "explicit retry verifies fresh frame while already stopped");

                Field<Button>(form, "_verificationAction").PerformClick();
                await (Task)Call(form, "RunConveyorAsync")!;
                feed.Image = blank.ToBytes(".jpg");
                await Task.Delay(300);
                await (Task)Call(form, "InspectCameraAsync")!;
                feed.Image = phone;
                belt.OnStop = () => feed.Freeze = true;
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(server.InspectionCount == 2 && Field<bool>(form, "_verificationHold") && !Field<bool>(form, "_verificationCompleted"), "stale frame after STOP times out without saving or restarting");
                Check(Field<Label>(form, "_inspectionState").Text.Contains("새 카메라"), "fresh-frame timeout is visible to operator");
                feed.Freeze = false;
                belt.OnStop = null;
                start = (Task)Call(form, "StartInspectionAsync")!;
                Field<System.Windows.Forms.Timer>(form, "_inspectionTimer").Stop();
                await start;
                Check(server.InspectionCount == 3 && Field<bool>(form, "_verificationCompleted"), "camera recovery can be verified by explicit retry");

                Field<Button>(form, "_verificationAction").PerformClick();
                await (Task)Call(form, "RunConveyorAsync")!;
                feed.Image = blank.ToBytes(".jpg");
                await Task.Delay(300);
                await (Task)Call(form, "InspectCameraAsync")!;
                feed.Image = phone;
                belt.FailStop = true;
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(server.InspectionCount == 3 && !Field<bool>(form, "_runningInspection"), "missing STOP acknowledgment prevents verification and saving");
                Check(Field<Label>(form, "_conveyorState").Text.Contains("정지 응답을 확인하지 못했습니다"), "missing STOP acknowledgment shown as an error");

                foreach (var size in new[] { new System.Drawing.Size(1400, 900), new System.Drawing.Size(1100, 740) })
                {
                    form.Size = size;
                    form.PerformLayout();
                    var toolbars = Field<Button>(form, "_inspectionStart").Parent!.Parent!.Controls.OfType<FlowLayoutPanel>().ToArray();
                    Check(toolbars.Length == 4 && toolbars.All(panel => panel.Controls.Cast<Control>().All(control =>
                        panel.ClientRectangle.Contains(control.Bounds))), $"all camera, model, belt and verification controls visible at {size.Width}x{size.Height}");
                    var button = Field<Button>(form, "_verificationAction");
                    Check(button.Parent!.ClientRectangle.Contains(button.Bounds), $"verification button visible at {size.Width}x{size.Height}");
                    var setupButton = Field<Button>(form, "_arduinoSetup");
                    Check(setupButton.Parent!.ClientRectangle.Contains(setupButton.Bounds), $"integrated Arduino setup button visible at {size.Width}x{size.Height}");
                    using var preview = new Bitmap(form.Width, form.Height);
                    form.DrawToBitmap(preview, new Rectangle(System.Drawing.Point.Empty, form.Size));
                    preview.Save(Path.Combine(AppContext.BaseDirectory, $"conveyor-controls-{size.Width}.png"));
                }
                Console.WriteLine("ALL STOPPED-INSPECTION CHECKS PASSED; no physical COM port or motor used.");
            }
            catch (Exception ex) { Console.Error.WriteLine(ex); Environment.ExitCode = 1; }
            finally { Call(form, "DisconnectCamera"); form.Close(); }
        };
        Application.Run(form);
    }

    private sealed class MutableFeed(byte[] image) : ICameraFeed
    {
        private long _sequence;
        private CameraFrame? _last;
        public byte[] Image { get; set; } = image;
        public bool Freeze { get; set; }
        public int ReadCount { get; private set; }
        public string? Error => null;
        public CameraFrame Latest
        {
            get { ReadCount++; return Freeze && _last != null ? _last : _last = new(Image, ++_sequence, DateTime.UtcNow); }
        }
        public Task Completion => Task.CompletedTask;
        public void Dispose() { }
    }

    private sealed class TestConveyor : IConveyorController
    {
        public bool IsRunning { get; private set; } = true;
        public int StopCount { get; private set; }
        public int RunCount { get; private set; }
        public bool FailStop { get; set; }
        public Action? OnStop { get; set; }
        public Task RunAsync() { RunCount++; IsRunning = true; return Task.CompletedTask; }
        public Task StopAsync()
        {
            if (FailStop) throw new IOException("Synthetic missing STOPPED response");
            StopCount++; IsRunning = false; OnStop?.Invoke(); return Task.CompletedTask;
        }
        public Task PingAsync() => Task.CompletedTask;
        public void Dispose() { IsRunning = false; }
    }
}
