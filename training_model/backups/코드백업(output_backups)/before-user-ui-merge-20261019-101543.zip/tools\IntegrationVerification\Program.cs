using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using ProductionLine.AdminApp;
using ProductionLine.AdminApp.Services;
using ProductionLine.Shared;
using ProductionLine.UserApp;

internal static class Program
{
    private const BindingFlags Flags = BindingFlags.Instance | BindingFlags.NonPublic;
    private static int _checks;

    [STAThread]
    private static void Main(string[] args)
    {
        if (args.Length != 2) throw new ArgumentException("Pass the test server DLL and a separate verification output directory.");
        Application.SetHighDpiMode(HighDpiMode.SystemAware);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        var serverDll = Path.GetFullPath(args[0]);
        var runDirectory = Path.GetFullPath(args[1]);
        Directory.CreateDirectory(runDirectory);
        var dataDirectory = Path.Combine(runDirectory, "isolated-server-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(dataDirectory);
        using var portSelector = new TcpListener(IPAddress.Loopback, 0);
        portSelector.Start();
        var port = ((IPEndPoint)portSelector.LocalEndpoint).Port;
        portSelector.Stop();
        var url = $"http://127.0.0.1:{port}";
        var start = new ProcessStartInfo("dotnet")
        {
            WorkingDirectory = dataDirectory,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        start.ArgumentList.Add(serverDll);
        start.Environment["ServerUrl"] = url;
        start.Environment["GEMINI_API_KEY"] = "";
        start.Environment["OPENAI_API_KEY"] = "";
        start.Environment["Gemini__ApiKey"] = "";
        start.Environment["OpenAI__ApiKey"] = "";
        start.Environment["AI_PROVIDER"] = "Gemini";
        start.Environment["Ai__Enabled"] = "false";
        using var server = Process.Start(start) ?? throw new IOException("Cannot start verification server.");
        var serverLog = server.StandardOutput.ReadToEndAsync();
        var serverError = server.StandardError.ReadToEndAsync();
        using var runner = new Form { Text = "통합 기능 검증", Size = new Size(400, 200), ShowInTaskbar = false };
        runner.Shown += async (_, _) =>
        {
            try
            {
                using var health = new HttpClient();
                for (var attempt = 0; ; attempt++)
                {
                    if (server.HasExited) throw new IOException("Verification server exited before becoming ready.");
                    try { using var reply = await health.GetAsync(url); if (reply.IsSuccessStatusCode) break; }
                    catch (HttpRequestException) { }
                    if (attempt >= 100) throw new TimeoutException("Verification server did not become ready.");
                    await Task.Delay(100);
                }
                await VerifyAsync(url, runDirectory);
                server.Kill(entireProcessTree: true);
                await server.WaitForExitAsync();
                using (var restarted = Process.Start(start) ?? throw new IOException("Cannot restart test server."))
                {
                    var restartedOutput = restarted.StandardOutput.ReadToEndAsync();
                    var restartedError = restarted.StandardError.ReadToEndAsync();
                    try
                    {
                        using var restored = new ProductionLineApiClient(url);
                        for (var attempt = 0; ; attempt++)
                        {
                            try { await restored.LoginAsync("worker1", "worker123!"); break; }
                            catch (HttpRequestException) when (attempt < 100) { await Task.Delay(100); }
                        }
                        var photoRecords = (await restored.GetInspectionsAsync(1)).Where(x => x.HasImage).ToList();
                        Check(photoRecords.Count == 2, "photo metadata survives server restart");
                        foreach (var record in photoRecords)
                        {
                            var bytes = await restored.GetInspectionImageAsync(record.Id);
                            using var stream = new MemoryStream(bytes);
                            using var image = new Bitmap(stream);
                            var pixel = image.GetPixel(5, 5);
                            Check(record.Reason.Contains("red-photo") ? pixel.R > 200 && pixel.B < 50 : pixel.B > 200 && pixel.R < 50,
                                "persisted photo remains matched to original inspection after server restart");
                        }
                    }
                    finally
                    {
                        if (!restarted.HasExited) restarted.Kill(entireProcessTree: true);
                        await restarted.WaitForExitAsync();
                        File.WriteAllText(Path.Combine(runDirectory, "server-restart.log"), await restartedOutput + await restartedError);
                    }
                }
                Console.WriteLine($"Passed {_checks} administrator/user/server integration checks.");
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine(exception);
                Environment.ExitCode = 1;
            }
            finally { runner.Close(); }
        };
        try { Application.Run(runner); }
        finally
        {
            if (!server.HasExited) server.Kill(entireProcessTree: true);
            server.WaitForExit();
            File.WriteAllText(Path.Combine(runDirectory, "server-test.log"),
                serverLog.GetAwaiter().GetResult() + serverError.GetAwaiter().GetResult());
        }
    }

    private static async Task VerifyAsync(string url, string output)
    {
        using var admin = new ProductionLineApiClient(url);
        using var worker = new ProductionLineApiClient(url);
        var adminAuth = new ApiAdminAuthService(admin);
        var adminUser = await adminAuth.LoginAsync("admin", "admin123!");
        Check(adminUser.Role == UserRole.Admin, "administrator authenticates against real server");
        using (var deniedApi = new ProductionLineApiClient(url))
            await RejectAsync(() => new ApiAdminAuthService(deniedApi).LoginAsync("worker1", "worker123!"), "worker rejected from administrator service");
        await worker.LoginAsync("worker1", "worker123!");
        await RejectAsync(() => worker.GetUsersAsync(), "worker cannot query administrator user list");
        await RejectAsync(() => worker.CreateUserAsync(new("forbidden", "권한 없음", "worker123!", [1])), "worker cannot create accounts");
        var dashboard = new ApiDashboardService(admin);
        var details = new ApiLineDetailService(admin);
        var users = new ApiUserService(admin);
        Check((await dashboard.GetLinesAsync()).Count == 4 && (await worker.GetLinesAsync()).Count == 1,
            "dashboard sees four lines while worker sees allowed line");
        var created = await users.CreateUserAsync(new("integration-" + Guid.NewGuid().ToString("N"), "통합 작업자", "first123!", [1]));
        using var changedWorker = new ProductionLineApiClient(url);
        await changedWorker.LoginAsync(created.Id, "first123!");
        await users.UpdateUserAsync(created.Id, new("변경 작업자", true, [2], "second123!"));
        await RejectAsync(() => changedWorker.GetLinesAsync(), "account update expires existing login");
        await RejectAsync(() => changedWorker.LoginAsync(created.Id, "first123!"), "old password no longer works");
        await changedWorker.LoginAsync(created.Id, "second123!");
        Check((await changedWorker.GetLinesAsync()).Single().Id == 2, "updated line permissions are enforced");
        await RejectAsync(() => changedWorker.GetInspectionsAsync(1), "removed line access is denied");
        await users.UpdateUserAsync(created.Id, new("변경 작업자", false, [2]));
        await RejectAsync(() => changedWorker.GetLinesAsync(), "deactivation expires already authenticated user");
        await RejectAsync(() => changedWorker.LoginAsync(created.Id, "second123!"), "deactivated account cannot log in");
        await users.UpdateUserAsync(created.Id, new("변경 작업자", true, [1]));
        Check((await changedWorker.LoginAsync(created.Id, "second123!")).IsActive, "account can be reactivated");

        var normal = await worker.SimulateInspectionAsync(new(1, 1, 1));
        var defect = await worker.SimulateInspectionAsync(new(1, 0, 1));
        Check(normal.Result == InspectionResultType.Normal && defect.Result == InspectionResultType.Defect,
            "existing camera inspection contract still saves results");
        Check((await details.GetInspectionsAsync(1)).Count == 2 && (await dashboard.GetLinesAsync()).Single(x => x.Id == 1).DefectCount == 1,
            "administrator reads same inspection records and counts as user");

        var beforeCamera = (await dashboard.GetLinesAsync()).Single(x => x.Id == 1);
        var presence = await worker.SaveCameraInspectionAsync(new(1, InspectionResultType.Normal, "휴대폰 검출: iphone_16", 0.87, false));
        Check(presence.Result == InspectionResultType.Undetermined && presence.Reason.Contains("판정")
            && presence.DetectionConfidence == 0.87, "phone-only camera result is forced to unclassified and preserves confidence");
        Check(presence.Reason.Contains("iphone_16") && presence.Reason.Contains("품질 판정 미지원"),
            "server preserves detected phone model name alongside its unclassified quality state");
        var afterCamera = (await dashboard.GetLinesAsync()).Single(x => x.Id == 1);
        Check(afterCamera.NormalCount == beforeCamera.NormalCount && afterCamera.DefectCount == beforeCamera.DefectCount
            && afterCamera.UndeterminedCount == beforeCamera.UndeterminedCount + 1,
            "phone arrival does not inflate normal or defective product counts");
        await RejectAsync(() => worker.SaveCameraInspectionAsync(new(2, InspectionResultType.Undetermined, "denied", 0.8, false)),
            "camera endpoint enforces line permissions");
        await RejectAsync(() => worker.SaveCameraInspectionAsync(new(1, InspectionResultType.Undetermined, "invalid score", 1.1, false)),
            "camera endpoint validates confidence range");

        var redImage = MakePhoto(Color.Red);
        var blueImage = MakePhoto(Color.Blue);
        var redRecord = await worker.SaveCameraInspectionAsync(new(1, InspectionResultType.Undetermined, "red-photo", 0.9, false, redImage));
        var blueRecord = await worker.SaveCameraInspectionAsync(new(1, InspectionResultType.Undetermined, "blue-photo", 0.8, false, blueImage));
        Check(redRecord.HasImage && blueRecord.HasImage && redRecord.Id != blueRecord.Id, "photo metadata belongs to distinct saved inspection IDs");
        Check((await worker.GetInspectionImageAsync(redRecord.Id)).SequenceEqual(redImage)
            && (await admin.GetInspectionImageAsync(blueRecord.Id)).SequenceEqual(blueImage), "worker and administrator retrieve exact photo bytes for selected record");
        await RejectAsync(() => worker.GetInspectionImageAsync(presence.Id), "legacy camera record without photo returns missing photo");
        await RejectAsync(() => worker.GetInspectionImageAsync(Guid.NewGuid()), "unknown photo record returns not found");
        await RejectAsync(() => worker.SaveCameraInspectionAsync(new(1, InspectionResultType.Undetermined, "invalid photo", 0.8, false, [1, 2, 3])),
            "invalid image upload is rejected without publishing photo record");
        using (var anonymous = new HttpClient())
        {
            using var response = await anonymous.GetAsync(url + $"/api/inspections/{redRecord.Id}/image");
            Check(response.StatusCode == HttpStatusCode.Unauthorized, "anonymous caller cannot retrieve inspection photo");
        }
        var otherLine = await users.CreateUserAsync(new("photos-other-" + Guid.NewGuid().ToString("N"), "다른 라인", "worker123!", [2]));
        using (var other = new ProductionLineApiClient(url))
        {
            await other.LoginAsync(otherLine.Id, "worker123!");
            await RejectAsync(() => other.GetInspectionImageAsync(redRecord.Id), "photo API enforces allowed line permissions");
        }

        var issue = await worker.CreateIssueAsync(new(1, IssueType.InspectionSystem, "카메라 점검", "영상 끊김 테스트"));
        await RejectAsync(() => worker.UpdateIssueAsync(issue.Id, new(IssueStatus.Closed, "직접 종결 시도")), "worker cannot close an issue");
        await RejectAsync(() => admin.UpdateIssueAsync(issue.Id, new(IssueStatus.Closed, "순서 건너뛰기")), "administrator cannot skip completion request");
        await worker.UpdateIssueAsync(issue.Id, new(IssueStatus.Acknowledged, "상태 확인"));
        await worker.UpdateIssueAsync(issue.Id, new(IssueStatus.InProgress, "케이블 점검"));
        await worker.UpdateIssueAsync(issue.Id, new(IssueStatus.CompletionRequested, "영상 복구 확인"));
        var rejected = await dashboard.UpdateIssueAsync(issue.Id, new(IssueStatus.InProgress, "추가 확인 필요"));
        Check(rejected.Status == IssueStatus.InProgress && rejected.ActionNote!.Contains("케이블 점검"), "administrator rejection preserves worker action notes");
        await worker.UpdateIssueAsync(issue.Id, new(IssueStatus.CompletionRequested, "추가 점검 완료"));

        var chatIssue = await worker.CreateIssueAsync(new(1, IssueType.ProductionLine, "습도 상담", "가상 상담 테스트"));
        var reply = await worker.ConsultAiAsync(new(chatIssue.Id, "습도가 높아요"));
        Check(reply.ManualSource.Contains("습도") && reply.NeedAdmin, "server consultation uses imported manuals");
        var followup = await worker.ConsultAiAsync(new(chatIssue.Id, "80%"));
        Check(followup.Answer.Contains("80%RH"), "server preserves authenticated user's follow-up context");
        Check((await worker.GetIssuesAsync()).Single(x => x.Id == chatIssue.Id).Status == IssueStatus.Occurred,
            "AI conversation does not change issue status");

        await PreviewAsync(new AdminLoginForm(adminAuth, dashboard, details, users), output, "admin-login", null);
        await PreviewAsync(new AdminMainForm(adminUser, dashboard, details, users), output, "admin-dashboard", "_loading");
        await PreviewAsync(new UserManagementForm(users, dashboard), output, "admin-users", "_busy");
        await PreviewAsync(new LineDetailForm(1, dashboard, details), output, "admin-line", "_loading");
        await PreviewAsync(new CompletionRequestForm(dashboard), output, "admin-completion", "_loading");
        await PreviewAsync(new InspectionIssueForm(dashboard, details), output, "admin-issues", "_loading");
        await PreviewAsync(new InspectionHistoryForm(dashboard, details), output, "admin-history", "_loading");
        string? temporaryConversation = null;
        await PreviewAsync(new UserMainForm(changedWorker), output, "user-ai", "_loading", async form =>
        {
            // 무작위 테스트 계정의 표시 이력만 생성합니다. 실제 사용자의 대화 파일은 사용하지 않습니다.
            temporaryConversation = (string)form.GetType().GetField("_conversationFile", Flags)!.GetValue(form)!;
            Check(!File.Exists(temporaryConversation), "UI conversation belongs to a new synthetic user");
            var pages = (TabControl)form.GetType().GetField("_pages", Flags)!.GetValue(form)!;
            pages.SelectedIndex = 3;
            var picker = (ComboBox)form.GetType().GetField("_aiIssue", Flags)!.GetValue(form)!;
            picker.SelectedItem = picker.Items.Cast<IssueDto>().Single(value => value.Id == chatIssue.Id);
            var input = (TextBox)form.GetType().GetField("_aiInput", Flags)!.GetValue(form)!;
            input.Text = "습도가 높아요";
            await (Task)form.GetType().GetMethod("SendChatAsync", Flags)!.Invoke(form, [false])!;
            input.Text = "80%";
            await (Task)form.GetType().GetMethod("SendChatAsync", Flags)!.Invoke(form, [false])!;
            var messages = (RichTextBox)form.GetType().GetField("_aiMessages", Flags)!.GetValue(form)!;
            var status = (Label)form.GetType().GetField("_aiReplyState", Flags)!.GetValue(form)!;
            Check(messages.Text.Contains("80%RH") && messages.Text.Contains("근거:"), "user UI displays multi-turn answer and manual evidence");
            Check(status.Text.Contains("기본 매뉴얼") && !status.Text.Contains("실패"), "user UI distinguishes manual mode from failed delivery");
        });
        if (temporaryConversation != null && File.Exists(temporaryConversation)) File.Delete(temporaryConversation);
        await PreviewAsync(new UserMainForm(worker), output, "user-history-photo", "_loading", async form =>
        {
            var pages = (TabControl)form.GetType().GetField("_pages", Flags)!.GetValue(form)!;
            pages.SelectedIndex = 1;
            var grid = (DataGridView)form.GetType().GetField("_history", Flags)!.GetValue(form)!;
            var photo = (PictureBox)form.GetType().GetField("_historyImage", Flags)!.GetValue(form)!;
            void Select(Guid id)
            {
                var row = grid.Rows.Cast<DataGridViewRow>().Single(r => (Guid)r.Cells["검사번호"].Value == id);
                grid.CurrentCell = row.Cells[0];
            }
            async Task ExpectColor(bool red)
            {
                for (var i = 0; i < 100; i++)
                {
                    if (photo.Image is Bitmap bitmap)
                    {
                        var pixel = bitmap.GetPixel(5, 5);
                        if (red ? pixel.R > 200 && pixel.B < 50 : pixel.B > 200 && pixel.R < 50) return;
                    }
                    await Task.Delay(20);
                }
                throw new InvalidOperationException("Selected history photo did not match its record.");
            }
            Select(redRecord.Id);
            await ExpectColor(true);
            Check(true, "selecting red-photo record displays its own image in history");
            Select(blueRecord.Id);
            await ExpectColor(false);
            Check(true, "switching history records replaces photo with corresponding blue image");
            Select(redRecord.Id);
            Select(presence.Id);
            await Task.Delay(100);
            Check(photo.Image == null && ((Label)form.GetType().GetField("_historyImageCaption", Flags)!.GetValue(form)!).Text.Contains("사진 없음"),
                "rapid selection to no-photo record cannot show stale previous image");
            Select(blueRecord.Id);
            await ExpectColor(false);
        });
        var closed = await dashboard.UpdateIssueAsync(issue.Id, new(IssueStatus.Closed, "관리자 검토 완료"));
        Check(closed.Status == IssueStatus.Closed && closed.ActionNote!.Contains("추가 확인 필요") && closed.ActionNote.Contains("추가 점검 완료"),
            "completion review closes issue with full notes preserved");
        await RejectAsync(() => dashboard.UpdateIssueAsync(issue.Id, new(IssueStatus.Closed, "중복 종결")), "duplicate close is rejected");
        Check((await worker.GetIssuesAsync()).Single(x => x.Id == issue.Id).Status == IssueStatus.Closed,
            "worker sees administrator's final closure");
    }

    private static async Task PreviewAsync(Form form, string output, string name, string? busyField, Func<Form, Task>? prepare = null)
    {
        using (form)
        {
            form.Show();
            await Task.Delay(100);
            for (var attempt = 0; busyField != null && attempt < 100 &&
                form.GetType().GetField(busyField, Flags)?.GetValue(form) is true; attempt++)
                await Task.Delay(50);
            if (prepare != null) await prepare(form);
            await Task.Delay(50);
            var statusField = form.GetType().GetField("_status", Flags) ?? form.GetType().GetField("_connection", Flags);
            var status = (statusField?.GetValue(form) as Label)?.Text ?? string.Empty;
            Check(!status.Contains("실패") && !status.Contains("불러오는 중"), name + " loads from actual server");
            using var image = new Bitmap(form.Width, form.Height);
            form.DrawToBitmap(image, new Rectangle(Point.Empty, form.Size));
            image.Save(Path.Combine(output, name + ".png"));
            form.Close();
        }
    }

    private static void Check(bool condition, string name)
    {
        if (!condition) throw new InvalidOperationException(name);
        _checks++;
        Console.WriteLine("PASS: " + name);
    }

    private static byte[] MakePhoto(Color color)
    {
        using var image = new Bitmap(32, 32);
        using (var graphics = Graphics.FromImage(image)) graphics.Clear(color);
        using var stream = new MemoryStream();
        image.Save(stream, System.Drawing.Imaging.ImageFormat.Jpeg);
        return stream.ToArray();
    }

    private static async Task RejectAsync<T>(Func<Task<T>> operation, string name)
    {
        try { await operation(); }
        catch (InvalidOperationException) { Check(true, name); return; }
        throw new InvalidOperationException("Unexpected success: " + name);
    }
}
