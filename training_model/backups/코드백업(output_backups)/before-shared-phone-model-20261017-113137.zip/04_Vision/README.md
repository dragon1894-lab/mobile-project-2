# 4번 - 아이폰 영상처리

`ProductionLine.Vision`은 학습한 YOLO ONNX 모델을 C#에서 실행하여 다음 클래스를 검사합니다.

- `target_iphone`: 목표 아이폰
- `other_phone`: 목표 기종이 아닌 휴대폰
- `crack`: 표면 깨짐

## 모델 위치

학습 도구가 만든 모델을 다음 위치에 둡니다.

```text
04_Vision/models/best.onnx
```

빌드하면 모델이 실행 폴더의 `Models/best.onnx`로 자동 복사됩니다.

## 단독 테스트

Visual Studio에서 `ProductionLine.Vision.Tester`를 시작 프로젝트로 설정하고 실행합니다.
기본 샘플을 검사한 뒤 `04_Vision/output/iphone_result.jpg`에 검출 박스를 저장합니다.

명령줄에서 사진과 모델을 직접 지정할 수도 있습니다.

```text
ProductionLine.Vision.Tester.exe "사진.jpg" "best.onnx" 0.25
```

세 번째 값은 신뢰도 기준이며 기본값은 `0.25`입니다. 2026-10-17 두 번째 학습 모델(100회, 입력 640×640)을 반영하면서 이전 임시 4% 기준을 25%로 변경했습니다. 기존 아이폰 샘플에서 신뢰도 79.6% 검출을 확인했습니다. 이는 해당 사진의 모델 신뢰도이며 전체 검사 정확도를 뜻하지 않습니다.

## C# 호출 방법

```csharp
using var inspector = new YoloOnnxInspector();
var result = inspector.Inspect(imageBytes);
```

카메라 반복 검사에서는 `YoloOnnxInspector`를 한 번 만들고 계속 재사용해야 합니다. 매 프레임마다 생성하면 ONNX 모델을 반복해서 읽어 속도가 크게 느려집니다.

기존 `OpenCvSharpFrameAnalyzer`는 이전 화장품 뚜껑 검사 코드로 남겨 두었습니다. 사용자 화면과 서버를 아이폰 검사로 전환할 때는 `YoloOnnxInspector` 결과를 연결합니다.
