using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;
using OpenCvSharp;
using ProductionLine.Shared;

namespace ProductionLine.Vision;

/// <summary>
/// 학습 도구가 만든 Ultralytics YOLO ONNX 모델을 C#에서 실행합니다.
/// 한 인스턴스를 재사용해야 매 프레임마다 모델을 다시 읽지 않습니다.
/// </summary>
public sealed class YoloOnnxInspector : IDisposable
{
    public const string TargetIphone = "target_iphone";
    public const string OtherPhone = "other_phone";
    public const string Crack = "crack";

    private static readonly string[] ClassNames = [TargetIphone, OtherPhone, Crack];
    private readonly InferenceSession _session;
    private readonly string _inputName;
    private readonly int _inputWidth;
    private readonly int _inputHeight;
    private bool _disposed;

    public string ModelPath { get; }
    public float ConfidenceThreshold { get; }
    public float IouThreshold { get; }

    public YoloOnnxInspector(
        string? modelPath = null,
        float confidenceThreshold = 0.25f,
        float iouThreshold = 0.45f)
    {
        ModelPath = ResolveModelPath(modelPath);
        ConfidenceThreshold = Math.Clamp(confidenceThreshold, 0.01f, 0.99f);
        IouThreshold = Math.Clamp(iouThreshold, 0.01f, 0.99f);

        _session = new InferenceSession(ModelPath);
        _inputName = _session.InputMetadata.Keys.Single();
        var dimensions = _session.InputMetadata[_inputName].Dimensions;
        if (dimensions.Length != 4 || dimensions[2] <= 0 || dimensions[3] <= 0)
            throw new InvalidOperationException("지원하지 않는 YOLO 입력 크기입니다.");
        _inputHeight = dimensions[2];
        _inputWidth = dimensions[3];
    }

    public YoloInspectionAnalysis Inspect(byte[] imageBytes)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        using var image = Cv2.ImDecode(imageBytes, ImreadModes.Color);
        if (image.Empty()) return YoloInspectionAnalysis.Failed("이미지를 읽지 못했습니다.");

        var (tensor, scale, padX, padY) = CreateInput(image);
        var input = NamedOnnxValue.CreateFromTensor(_inputName, tensor);
        using var results = _session.Run([input]);
        var output = results.First().AsTensor<float>();
        var detections = ApplyNms(ParseOutput(output, image.Size(), scale, padX, padY));

        using var annotated = image.Clone();
        foreach (var detection in detections)
            DrawDetection(annotated, detection);
        Cv2.ImEncode(".jpg", annotated, out var resultImage);

        var hasTarget = detections.Any(value => value.ClassName == TargetIphone);
        var hasOther = detections.Any(value => value.ClassName == OtherPhone);
        var hasCrack = detections.Any(value => value.ClassName == Crack);

        if (hasCrack)
            return new YoloInspectionAnalysis(true, InspectionResultType.Defect,
                "표면 깨짐이 검출되었습니다.", detections, resultImage);
        if (hasOther)
            return new YoloInspectionAnalysis(true, InspectionResultType.Defect,
                "검사 대상 아이폰이 아닌 제품이 검출되었습니다.", detections, resultImage);
        if (hasTarget)
            return new YoloInspectionAnalysis(true, InspectionResultType.Normal,
                "목표 아이폰이 검출되었고 깨짐은 검출되지 않았습니다.", detections, resultImage);

        return new YoloInspectionAnalysis(false, InspectionResultType.Undetermined,
            $"신뢰도 {ConfidenceThreshold:P0} 이상인 휴대폰을 찾지 못했습니다.", detections, resultImage);
    }

    private (DenseTensor<float> Tensor, float Scale, float PadX, float PadY) CreateInput(Mat image)
    {
        var scale = Math.Min(_inputWidth / (float)image.Width, _inputHeight / (float)image.Height);
        var resizedWidth = Math.Max(1, (int)Math.Round(image.Width * scale));
        var resizedHeight = Math.Max(1, (int)Math.Round(image.Height * scale));
        var padX = (_inputWidth - resizedWidth) / 2f;
        var padY = (_inputHeight - resizedHeight) / 2f;

        using var resized = new Mat();
        Cv2.Resize(image, resized, new Size(resizedWidth, resizedHeight), 0, 0, InterpolationFlags.Linear);
        using var letterboxed = new Mat(new Size(_inputWidth, _inputHeight), MatType.CV_8UC3, new Scalar(114, 114, 114));
        var left = (int)Math.Floor(padX);
        var top = (int)Math.Floor(padY);
        using (var region = new Mat(letterboxed, new Rect(left, top, resizedWidth, resizedHeight)))
            resized.CopyTo(region);
        using var rgb = new Mat();
        Cv2.CvtColor(letterboxed, rgb, ColorConversionCodes.BGR2RGB);

        var tensor = new DenseTensor<float>([1, 3, _inputHeight, _inputWidth]);
        for (var y = 0; y < _inputHeight; y++)
        {
            for (var x = 0; x < _inputWidth; x++)
            {
                var pixel = rgb.At<Vec3b>(y, x);
                tensor[0, 0, y, x] = pixel.Item0 / 255f;
                tensor[0, 1, y, x] = pixel.Item1 / 255f;
                tensor[0, 2, y, x] = pixel.Item2 / 255f;
            }
        }
        return (tensor, scale, left, top);
    }

    private List<YoloDetection> ParseOutput(Tensor<float> output, OpenCvSharp.Size originalSize, float scale, float padX, float padY)
    {
        if (output.Dimensions.Length != 3)
            throw new InvalidOperationException("지원하지 않는 YOLO 출력 형식입니다.");

        var featuresFirst = output.Dimensions[1] == ClassNames.Length + 4;
        var featuresLast = output.Dimensions[2] == ClassNames.Length + 4;
        if (!featuresFirst && !featuresLast)
            throw new InvalidOperationException($"YOLO 출력 클래스 수가 맞지 않습니다. 출력: {string.Join('x', output.Dimensions.ToArray())}");

        var candidateCount = featuresFirst ? output.Dimensions[2] : output.Dimensions[1];
        float Value(int feature, int candidate) => featuresFirst
            ? output[0, feature, candidate]
            : output[0, candidate, feature];

        var detections = new List<YoloDetection>();
        for (var candidate = 0; candidate < candidateCount; candidate++)
        {
            var classId = 0;
            var confidence = Value(4, candidate);
            for (var index = 1; index < ClassNames.Length; index++)
            {
                var score = Value(4 + index, candidate);
                if (score <= confidence) continue;
                confidence = score;
                classId = index;
            }
            if (confidence < ConfidenceThreshold) continue;

            var centerX = Value(0, candidate);
            var centerY = Value(1, candidate);
            var width = Value(2, candidate);
            var height = Value(3, candidate);
            var left = (centerX - width / 2 - padX) / scale;
            var top = (centerY - height / 2 - padY) / scale;
            var right = (centerX + width / 2 - padX) / scale;
            var bottom = (centerY + height / 2 - padY) / scale;

            left = Math.Clamp(left, 0, originalSize.Width - 1);
            top = Math.Clamp(top, 0, originalSize.Height - 1);
            right = Math.Clamp(right, 0, originalSize.Width);
            bottom = Math.Clamp(bottom, 0, originalSize.Height);
            if (right - left < 2 || bottom - top < 2) continue;

            detections.Add(new YoloDetection(
                classId,
                ClassNames[classId],
                confidence,
                new System.Drawing.RectangleF(left, top, right - left, bottom - top)));
        }
        return detections;
    }

    private IReadOnlyList<YoloDetection> ApplyNms(IEnumerable<YoloDetection> values)
    {
        var kept = new List<YoloDetection>();
        foreach (var candidate in values.OrderByDescending(value => value.Confidence))
        {
            // 목표/다른 휴대폰은 같은 제품 그룹으로 경쟁시키고, crack 박스는 별도로 유지합니다.
            var candidateGroup = candidate.ClassName == Crack ? Crack : "phone";
            var overlaps = kept.Any(existing =>
                (existing.ClassName == Crack ? Crack : "phone") == candidateGroup &&
                IntersectionOverUnion(existing.Box, candidate.Box) > IouThreshold);
            if (!overlaps) kept.Add(candidate);
        }
        return kept;
    }

    private static float IntersectionOverUnion(System.Drawing.RectangleF first, System.Drawing.RectangleF second)
    {
        var intersection = System.Drawing.RectangleF.Intersect(first, second);
        if (intersection.Width <= 0 || intersection.Height <= 0) return 0;
        var intersectionArea = intersection.Width * intersection.Height;
        var unionArea = first.Width * first.Height + second.Width * second.Height - intersectionArea;
        return unionArea <= 0 ? 0 : intersectionArea / unionArea;
    }

    private static void DrawDetection(Mat image, YoloDetection detection)
    {
        var color = detection.ClassName switch
        {
            TargetIphone => new Scalar(0, 200, 0),
            OtherPhone => new Scalar(0, 165, 255),
            Crack => new Scalar(0, 0, 255),
            _ => new Scalar(255, 255, 255)
        };
        var rectangle = new Rect(
            (int)detection.Box.X,
            (int)detection.Box.Y,
            Math.Max(1, (int)detection.Box.Width),
            Math.Max(1, (int)detection.Box.Height));
        Cv2.Rectangle(image, rectangle, color, 3);
        var label = $"{detection.ClassName} {detection.Confidence:P0}";
        Cv2.PutText(image, label,
            new Point(rectangle.X, Math.Max(25, rectangle.Y - 8)),
            HersheyFonts.HersheySimplex, 0.7, color, 2);
    }

    private static string ResolveModelPath(string? modelPath)
    {
        if (!string.IsNullOrWhiteSpace(modelPath))
        {
            var explicitPath = Path.GetFullPath(modelPath);
            if (File.Exists(explicitPath)) return explicitPath;
            throw new FileNotFoundException("YOLO ONNX 모델을 찾지 못했습니다.", explicitPath);
        }

        var candidates = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "Models", "best.onnx"),
            Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "models", "best.onnx"))
        };
        return candidates.FirstOrDefault(File.Exists)
            ?? throw new FileNotFoundException("Models/best.onnx를 찾지 못했습니다. 모델의 출력 복사 설정을 확인하세요.");
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _session.Dispose();
    }
}

public sealed record YoloDetection(
    int ClassId,
    string ClassName,
    float Confidence,
    System.Drawing.RectangleF Box);

public sealed record YoloInspectionAnalysis(
    bool ObjectFound,
    InspectionResultType Result,
    string Reason,
    IReadOnlyList<YoloDetection> Detections,
    byte[] ResultImage)
{
    public static YoloInspectionAnalysis Failed(string reason) =>
        new(false, InspectionResultType.Undetermined, reason, [], []);
}
