using System.Reflection;
using OpenCvSharp;
using ProductionLine.Shared;
using ProductionLine.UserApp;
using ProductionLine.Vision;

namespace ProductionLine.Verification;

internal static class ContinuousYoloChecks
{
    private const BindingFlags Flags = BindingFlags.Instance | BindingFlags.NonPublic;
    private static T Field<T>(object instance, string name) =>
        (T)instance.GetType().GetField(name, Flags)!.GetValue(instance)!;
    private static object? Call(object instance, string name, params object[] args) =>
        instance.GetType().GetMethod(name, Flags)!.Invoke(instance, args);
    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
        Console.WriteLine("PASS: " + message);
    }

    public static void Run()
    {
        Application.SetHighDpiMode(HighDpiMode.SystemAware);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        var imagePath = Environment.GetCommandLineArgs().Skip(2).FirstOrDefault()
            ?? throw new ArgumentException("Pass an iPhone sample image after --continuous-yolo.");
        var phone = File.ReadAllBytes(imagePath);
        using var blank = new Mat(1080, 1920, MatType.CV_8UC3, Scalar.Black);
        using var server = new TestServer();
        using var api = new ProductionLineApiClient(server.Url);
        api.LoginAsync("test", "test").GetAwaiter().GetResult();
        using var form = new UserMainForm(api);
        var feed = new MutableFeed(phone);
        form.Shown += async (_, _) =>
        {
            try
            {
                await ConveyorProtocolChecks.RunAsync();
                for (var attempt = 0; attempt < 200 && Field<bool>(form, "_loading"); attempt++)
                    await Task.Delay(25);
                await (Task)Call(form, "RefreshAsync", false)!;
                Field<System.Windows.Forms.Timer>(form, "_refresh").Stop();
                Field<System.Windows.Forms.Timer>(form, "_frames").Stop();
                typeof(UserMainForm).GetField("_camera", Flags)!.SetValue(form, feed);
                var conveyor = new TestConveyor();
                typeof(UserMainForm).GetField("_conveyor", Flags)!.SetValue(form, conveyor);
                await (Task)Call(form, "StartInspectionAsync")!;
                var timer = Field<System.Windows.Forms.Timer>(form, "_inspectionTimer");
                timer.Stop();
                Check(timer.Interval == 100, "100ms target interval");
                Check(server.InspectionCount == 1, "first phone counted once using actual ONNX model");
                Check(conveyor.StopCount == 1 && !conveyor.IsRunning, "actual YOLO phone detection sends conveyor stop");
                var picture = Field<PictureBox>(form, "_video");
                var previousImage = picture.Image;
                await conveyor.RunAsync();
                await Task.Delay(110);
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(!ReferenceEquals(previousImage, picture.Image), "same phone gets a fresh annotated frame");
                Check(server.InspectionCount == 1, "continuous frames do not duplicate product counts");
                Check(conveyor.StopCount == 2, "phone still stops a restarted belt before duplicate-count guard");
                var result = Field<Label>(form, "_result");
                Check(result.Text.StartsWith("YOLO 연속 검사"), "live YOLO result stays visible");
                await (Task)Call(form, "RefreshAsync", false)!;
                Check(result.Text.StartsWith("YOLO 연속 검사"), "server refresh does not overwrite live result");
                feed.Image = blank.ToBytes(".jpg");
                await conveyor.RunAsync();
                await Task.Delay(300);
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(!Field<bool>(form, "_productPresent"), "empty belt rearms product counting");
                Check(conveyor.IsRunning && conveyor.StopCount == 2, "empty frame does not stop conveyor");
                await (Task)Call(form, "StopOnPhoneAsync", new YoloInspectionAnalysis(true, InspectionResultType.Defect, "crack only",
                    [new YoloDetection(2, YoloOnnxInspector.Crack, 0.9f, new(10, 10, 20, 20))], []))!;
                Check(conveyor.IsRunning, "crack-only detection does not trigger phone arrival");
                feed.Image = phone;
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(server.InspectionCount == 2, "returning phone counts as next product");
                Check(conveyor.StopCount == 3 && !conveyor.IsRunning, "next phone stops conveyor again");
                Call(form, "StopInspection", "test stop");
                previousImage = picture.Image;
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(ReferenceEquals(previousImage, picture.Image) && server.InspectionCount == 2,
                    "stop prevents analysis and additional records");
                Check(!Field<bool>(form, "_inspectionBusy"), "no analysis left running");
                var failingConveyor = new TestConveyor { FailStop = true };
                typeof(UserMainForm).GetField("_conveyor", Flags)!.SetValue(form, failingConveyor);
                await (Task)Call(form, "StartInspectionAsync")!;
                Field<System.Windows.Forms.Timer>(form, "_inspectionTimer").Stop();
                Check(!Field<bool>(form, "_runningInspection") && server.InspectionCount == 2,
                    "unconfirmed conveyor stop halts inspection without recording success");
                Check(Field<Label>(form, "_conveyorState").Text.Contains("정지 응답을 확인하지 못했습니다"),
                    "missing stop acknowledgment is shown as an error");
                form.WindowState = FormWindowState.Normal;
                form.Size = new System.Drawing.Size(1400, 900);
                form.PerformLayout();
                using var preview = new Bitmap(form.Width, form.Height);
                form.DrawToBitmap(preview, new Rectangle(System.Drawing.Point.Empty, form.Size));
                preview.Save(Path.Combine(AppContext.BaseDirectory, "conveyor-controls-preview.png"));
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine(exception);
                Environment.ExitCode = 1;
            }
            finally
            {
                Call(form, "DisconnectCamera");
                form.Close();
            }
        };
        Application.Run(form);
    }

    private sealed class MutableFeed(byte[] image) : ICameraFeed
    {
        private long _sequence;
        public byte[] Image { get; set; } = image;
        public string? Error => null;
        public CameraFrame Latest => new(Image, ++_sequence, DateTime.UtcNow);
        public Task Completion => Task.CompletedTask;
        public void Dispose() { }
    }

    private sealed class TestConveyor : IConveyorController
    {
        public bool IsRunning { get; private set; } = true;
        public int StopCount { get; private set; }
        public bool FailStop { get; init; }
        public Task RunAsync() { IsRunning = true; return Task.CompletedTask; }
        public Task StopAsync()
        {
            if (FailStop) throw new IOException("Synthetic missing STOPPED response");
            StopCount++;
            IsRunning = false;
            return Task.CompletedTask;
        }
        public Task PingAsync() => Task.CompletedTask;
        public void Dispose() => IsRunning = false;
    }
}
