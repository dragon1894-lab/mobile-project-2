using ProductionLine.Shared;
using ProductionLine.Vision;

namespace ProductionLine.UserApp;

public sealed partial class UserMainForm
{
    private ICameraFeed? _camera;
    private Task _cameraClosed = Task.CompletedTask;
    private readonly NumericUpDown _cameraIndex = new() { Minimum = 0, Maximum = 9, Width = 55 };
    private readonly Button _cameraConnect = new() { Text = "카메라 연결", AutoSize = true };
    private readonly Button _inspectionStart = new() { Text = "검사 시작", AutoSize = true };
    private readonly Label _inspectionState = new() { AutoSize = true, Text = "검사 대기 · 카메라 연결 후 YOLO 모델을 확인하세요.", Padding = new Padding(8) };
    private const int InspectionIntervalMs = 100;
    private readonly System.Windows.Forms.Timer _inspectionTimer = new() { Interval = InspectionIntervalMs };
    private YoloOnnxInspector? _yoloInspector;
    private const float PhoneConfidenceThreshold = 0.25f;
    private long _displayedFrame, _inspectedFrame;
    private bool _runningInspection, _inspectionBusy;
    private bool _productPresent;
    private DateTime _lastProductSeenUtc;
    private int _inspectionGeneration;

    private Control CameraControls()
    {
        var container = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 4, ColumnCount = 1 };
        container.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        container.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
        container.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
        container.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill };
        buttons.Controls.Add(new Label { Text = "카메라 번호", AutoSize = true, Padding = new Padding(0, 5, 0, 0) });
        buttons.Controls.Add(_cameraIndex);
        buttons.Controls.Add(_cameraConnect);
        buttons.Controls.Add(Button("연결 해제", DisconnectCamera));
        buttons.Controls.Add(Button("YOLO 모델 확인", CheckYoloModel));
        buttons.Controls.Add(_inspectionStart);
        buttons.Controls.Add(Button("검사 중지", () => StopInspection("검사 중지 · 전송 중인 1건은 완료될 수 있습니다.")));
        container.Controls.Add(buttons, 0, 0);
        container.Controls.Add(BuildConveyorControls(), 0, 1);
        container.Controls.Add(_conveyorState, 0, 2);
        container.Controls.Add(_inspectionState, 0, 3);
        _cameraConnect.Click += (_, _) => ConnectCamera();
        _inspectionStart.Click += async (_, _) => await StartInspectionAsync();
        _inspectionTimer.Tick += async (_, _) => await InspectCameraAsync();
        return container;
    }

    private void ConnectCamera()
    {
        if (_camera != null) return;
        if (!_cameraClosed.IsCompleted) { _videoStatus.Text = "이전 카메라 연결을 해제하는 중입니다. 잠시 후 다시 연결하세요."; return; }
        _displayedFrame = _inspectedFrame = 0;
        _productPresent = false;
        _lastProductSeenUtc = default;
        _camera = new CameraSession((int)_cameraIndex.Value);
        _cameraConnect.Enabled = false; _cameraIndex.Enabled = false;
        _videoStatus.Text = "카메라 연결 중...";
        _frames.Interval = 50;
    }

    private void DisconnectCamera()
    {
        StopInspection("검사 대기 · 카메라를 다시 연결하세요.");
        var old = _camera; _camera = null;
        if (old != null) { old.Dispose(); _cameraClosed = old.Completion; }
        _productPresent = false;
        _lastProductSeenUtc = default;
        _cameraConnect.Enabled = true; _cameraIndex.Enabled = true;
        _video.Image?.Dispose(); _video.Image = null;
        _videoStatus.Text = "카메라 연결 해제됨";
        _frames.Interval = 500;
    }

    private void DisplayCameraFrame()
    {
        if (_camera == null) return;
        if (_camera.Error is string error)
        {
            DisconnectCamera(); _videoStatus.Text = error; return;
        }
        var frame = _camera.Latest;
        if (frame == null) return;
        if ((DateTime.UtcNow - frame.ReceivedUtc).TotalSeconds > 3)
        {
            StopInspection("영상 수신 지연으로 검사 중지");
            _videoStatus.Text = "카메라 영상이 3초 이상 갱신되지 않았습니다."; return;
        }
        // 검사 중에는 YOLO 결과 프레임을 표시합니다. 원본 영상이 박스를 덮어쓰지 않게 합니다.
        if (_runningInspection) return;
        if (frame.Sequence == _displayedFrame) return;
        using var stream = new MemoryStream(frame.Jpeg);
        using var source = Image.FromStream(stream);
        var old = _video.Image; _video.Image = new Bitmap(source); old?.Dispose();
        _displayedFrame = frame.Sequence;
        _videoStatus.Text = $"카메라 {_cameraIndex.Value} 연결됨 · {frame.ReceivedUtc.ToLocalTime():HH:mm:ss} · 프레임 {frame.Sequence}";
    }

    private void CheckYoloModel()
    {
        try
        {
            EnsureYoloInspector();
            _inspectionState.Text = $"YOLO 모델 준비 완료 · 신뢰도 기준 {PhoneConfidenceThreshold:P0} · 검사 시작을 누르세요.";
        }
        catch (Exception ex)
        {
            _inspectionState.Text = "YOLO 모델 준비 실패: " + ex.Message;
        }
    }

    private async Task StartInspectionAsync()
    {
        if (_runningInspection || _inspectionBusy) return;
        if (_camera?.Latest == null)
        { _inspectionState.Text = "먼저 카메라를 연결하세요."; return; }
        if (_lines.SelectedItem is not LineStatusDto { IsReal: true })
        { _inspectionState.Text = "실제 검사 가능한 라인을 선택하세요."; return; }
        try { EnsureYoloInspector(); }
        catch (Exception ex) { _inspectionState.Text = "YOLO 모델 준비 실패: " + ex.Message; return; }
        _runningInspection = true; _inspectionStart.Enabled = false;
        _productPresent = false;
        _lastProductSeenUtc = default;
        _inspectionGeneration++;
        _inspectionState.Text = "YOLO 연속 검사 중 · 목표 간격 0.1초 · 제품별 기록은 한 번 저장";
        _inspectionTimer.Start();
        await InspectCameraAsync();
    }

    private void StopInspection(string message)
    {
        _runningInspection = false; _inspectionGeneration++;
        _inspectionTimer.Stop(); _inspectionStart.Enabled = !_inspectionBusy;
        _inspectionState.Text = message;
        if (_stopOnPhone.Checked && _conveyor is { IsRunning: true })
            _ = StopConveyorWhenInspectionStopsAsync();
    }

    private async Task InspectCameraAsync()
    {
        if (!_runningInspection || _inspectionBusy) return;
        var frame = _camera?.Latest;
        if (frame == null || (DateTime.UtcNow - frame.ReceivedUtc).TotalSeconds > 3)
        { StopInspection("영상이 없어 검사를 중지했습니다. 카메라 연결을 확인하세요."); return; }
        if (frame.Sequence == _inspectedFrame) return;
        _inspectedFrame = frame.Sequence;
        var line = _lineId;
        var generation = _inspectionGeneration;
        _inspectionBusy = true;
        try
        {
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            var analysis = await Task.Run(() => _yoloInspector!.Inspect(frame.Jpeg));
            if (IsDisposed || !_runningInspection || generation != _inspectionGeneration) return;
            stopwatch.Stop();

            // 동일 제품도 매 프레임 표시를 갱신하고, 서버 저장에만 중복 방지를 적용합니다.
            ShowYoloResultImage(analysis.ResultImage);
            _displayedFrame = frame.Sequence;
            var confidence = analysis.Detections.Select(value => value.Confidence).DefaultIfEmpty(0).Max();
            _result.Text = $"YOLO 연속 검사: {ResultText(analysis.Result)} · 최고 신뢰도 {confidence:P1}\r\n{analysis.Reason} · 촬영 {frame.ReceivedUtc.ToLocalTime():HH:mm:ss.fff}";
            _result.ForeColor = analysis.Result == InspectionResultType.Defect ? UserTheme.Red : UserTheme.Text;
            _videoStatus.Text = $"카메라 {_cameraIndex.Value} · YOLO 처리 {stopwatch.ElapsedMilliseconds}ms · 목표 간격 {InspectionIntervalMs}ms · 프레임 {frame.Sequence}";
            await StopOnPhoneAsync(analysis);
            if (IsDisposed || !_runningInspection || generation != _inspectionGeneration) return;
            if (!analysis.ObjectFound)
            {
                if (_lastProductSeenUtc == default || (DateTime.UtcNow - _lastProductSeenUtc).TotalMilliseconds >= 250)
                    _productPresent = false;
                _inspectionState.Text = "YOLO 연속 검사 중 · 목표 간격 0.1초 · 휴대폰 감지 대기";
                return;
            }

            _lastProductSeenUtc = DateTime.UtcNow;
            _inspectionState.Text = "YOLO 연속 검사 중 · 목표 간격 0.1초 · 같은 제품은 중복 집계하지 않습니다.";
            if (_productPresent) return;
            _productPresent = true;

            if (IsDisposed || !_runningInspection || generation != _inspectionGeneration) return;

            var hasOtherPhone = analysis.Detections.Any(value => value.ClassName == YoloOnnxInspector.OtherPhone);
            var hasCrack = analysis.Detections.Any(value => value.ClassName == YoloOnnxInspector.Crack);

            // 기존 서버 계약을 유지하면서 YOLO 판정을 형태/색상 합격 값으로 변환합니다.
            var shapeScore = hasOtherPhone ? 0.0 : 1.0;
            var colorScore = hasCrack ? 0.0 : 1.0;
            await _api.SimulateInspectionAsync(new InspectionRequest(line, shapeScore, colorScore, true));
            if (IsDisposed || generation != _inspectionGeneration) return;
            _inspectionState.Text = $"YOLO 연속 검사 중 · 목표 간격 0.1초 · 제품 기록 저장 {DateTime.Now:HH:mm:ss}";
            await RefreshAsync(false);
        }
        catch (Exception ex)
        {
            if (!IsDisposed) StopInspection("검사 중지 · 분석/저장 실패: " + ex.Message + " · 자동 재전송하지 않습니다.");
        }
        finally
        {
            _inspectionBusy = false;
            if (!IsDisposed) _inspectionStart.Enabled = !_runningInspection;
            else _yoloInspector?.Dispose();
        }
    }

    private void EnsureYoloInspector()
    {
        _yoloInspector ??= new YoloOnnxInspector(confidenceThreshold: PhoneConfidenceThreshold);
    }

    private void ShowYoloResultImage(byte[] imageBytes)
    {
        if (imageBytes.Length == 0) return;
        using var stream = new MemoryStream(imageBytes);
        using var source = Image.FromStream(stream);
        var old = _video.Image;
        _video.Image = new Bitmap(source);
        old?.Dispose();
    }
}
