using System;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProductionLine.AdminApp.Services;
using ProductionLine.Shared;

namespace ProductionLine.AdminApp
{
    public sealed class AdminMainForm : Form
    {
        private readonly IDashboardService _service;
        private readonly ILineDetailService _detailService;
        private readonly IUserService _userService;

        private readonly DataGridView _lines =
            new DataGridView();

        private readonly Button _refresh = new Button();
        private readonly Label _status = new Label();

        private readonly Label _totalValue = MetricValue();
        private readonly Label _runningValue = MetricValue();
        private readonly Label _issueValue = MetricValue();
        private readonly Label _completionValue = MetricValue();

        private bool _loading;
        private readonly System.Windows.Forms.Timer _autoRefresh = new() { Interval = 5000 };

        public AdminMainForm(
            UserDto user,
            IDashboardService service,
            ILineDetailService detailService,
            IUserService userService)
        {
            _service = service ?? throw new ArgumentNullException(nameof(service));
            _detailService = detailService ?? throw new ArgumentNullException(nameof(detailService));
            _userService = userService ?? throw new ArgumentNullException(nameof(userService));

            Text = "생산라인 관리자 대시보드";
            ClientSize = new Size(1180, 720);
            MinimumSize = new Size(1000, 650);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(244, 247, 251);
            Font = new Font("맑은 고딕", 10F);

            BuildScreen(user);

            _lines.CellDoubleClick += OpenLineDetail;

            _autoRefresh.Tick += async (_, _) => await RefreshAsync();
            Shown += async (_, _) => { await RefreshAsync(); if (!IsDisposed) _autoRefresh.Start(); };
            FormClosed += (_, _) => _autoRefresh.Dispose();
        }

        private void BuildScreen(UserDto user)
        {
            var root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 5,
                Padding = new Padding(20)
            };

            root.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 65));
            root.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 115));
            root.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 45));
            root.RowStyles.Add(
                new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 35));

            var header = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1
            };

            header.ColumnStyles.Add(
                new ColumnStyle(SizeType.Percent, 100));
            header.ColumnStyles.Add(
                new ColumnStyle(SizeType.Absolute, 240));

            header.Controls.Add(new Label
            {
                Text = "전체 생산라인 대시보드",
                Dock = DockStyle.Fill,
                Font = new Font(
                    "맑은 고딕", 21F, FontStyle.Bold),
                ForeColor = Color.FromArgb(25, 45, 70),
                TextAlign = ContentAlignment.MiddleLeft
            }, 0, 0);

            header.Controls.Add(new Label
            {
                Text = $"로그인: {user.Name} ({user.Id})",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleRight
            }, 1, 0);

            var metrics = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 4,
                RowCount = 1
            };

            for (int i = 0; i < 4; i++)
            {
                metrics.ColumnStyles.Add(
                    new ColumnStyle(SizeType.Percent, 25));
            }

            metrics.Controls.Add(
                MetricCard("전체 라인", _totalValue), 0, 0);
            metrics.Controls.Add(
                MetricCard("가동 라인", _runningValue), 1, 0);
            metrics.Controls.Add(
                MetricCard("미종결 문제", _issueValue), 2, 0);
            metrics.Controls.Add(
                MetricCard("완료 요청", _completionValue), 3, 0);

            var toolbar = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                WrapContents = false
            };

            _refresh.Text = "새로고침";
            _refresh.AutoSize = true;
            _refresh.Click += async (_, _) =>
                await RefreshAsync();

            toolbar.Controls.Add(_refresh);
            var usersButton = new Button { Text = "사용자 관리", AutoSize = true };
            usersButton.Click += (_, _) =>
            {
                using var users = new UserManagementForm(_userService, _service);
                users.ShowDialog(this);
            };
            toolbar.Controls.Add(usersButton);
            var queryButton = new Button { Text = "검사 결과 / 문제 조회", AutoSize = true };
            queryButton.Click += (_, _) =>
            {
                using var query = new InspectionIssueForm(_service, _detailService);
                query.ShowDialog(this);
            };
            toolbar.Controls.Add(queryButton);
            var completionButton = new Button { Text = "완료 요청 확인", AutoSize = true };
            completionButton.Click += async (_, _) =>
            {
                using var requests = new CompletionRequestForm(_service);
                requests.ShowDialog(this);
                await RefreshAsync();
            };
            toolbar.Controls.Add(completionButton);
            var historyButton = new Button { Text = "검사 이력 / 통계", AutoSize = true };
            historyButton.Click += (_, _) =>
            {
                using var history = new InspectionHistoryForm(_service, _detailService);
                history.ShowDialog(this);
            };
            toolbar.Controls.Add(historyButton);
            toolbar.Controls.Add(new Label
            {
                Text = "대표 라인 더블클릭 → 상세",
                AutoSize = true,
                Margin = new Padding(15, 8, 0, 0),
                ForeColor = Color.DimGray
            });

            BuildGrid();

            _status.Dock = DockStyle.Fill;
            _status.TextAlign = ContentAlignment.MiddleLeft;
            _status.ForeColor = Color.DimGray;

            root.Controls.Add(header, 0, 0);
            root.Controls.Add(metrics, 0, 1);
            root.Controls.Add(toolbar, 0, 2);
            root.Controls.Add(_lines, 0, 3);
            root.Controls.Add(_status, 0, 4);

            Controls.Add(root);
        }

        private void BuildGrid()
        {
            _lines.Dock = DockStyle.Fill;
            _lines.ReadOnly = true;
            _lines.AllowUserToAddRows = false;
            _lines.AllowUserToDeleteRows = false;
            _lines.AllowUserToResizeRows = false;
            _lines.AutoGenerateColumns = false;
            _lines.RowHeadersVisible = false;
            _lines.MultiSelect = false;
            _lines.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;
            _lines.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;
            _lines.BackgroundColor = Color.White;
            _lines.BorderStyle = BorderStyle.None;
            _lines.RowTemplate.Height = 38;
            _lines.ColumnHeadersHeight = 42;
            _lines.EnableHeadersVisualStyles = false;

            _lines.ColumnHeadersDefaultCellStyle.BackColor =
                Color.FromArgb(25, 45, 70);
            _lines.ColumnHeadersDefaultCellStyle.ForeColor =
                Color.White;
            _lines.AlternatingRowsDefaultCellStyle.BackColor =
                Color.FromArgb(242, 246, 251);

            _lines.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Id",
                DataPropertyName = "Id",
                Visible = false
            });
            _lines.Columns.Add(new DataGridViewCheckBoxColumn
            {
                Name = "IsReal",
                DataPropertyName = "IsReal",
                Visible = false
            });

            AddColumn("Name", "라인", 180);
            AddColumn("Kind", "구분", 75);
            AddColumn("OperationStatus", "가동 상태", 95);
            AddColumn("InspectionStatus", "검사 상태", 110);
            AddColumn("NormalCount", "정상", 65);
            AddColumn("DefectCount", "불량", 65);
            AddColumn("UndeterminedCount", "판정 불가", 80);
            AddColumn("DefectRate", "불량률", 75);
            AddColumn("UpdatedAt", "데이터 갱신 시각", 150);

            _lines.Columns["UpdatedAt"]!
                .DefaultCellStyle.Format = "MM-dd HH:mm:ss";

            _lines.CellFormatting += (_, e) =>
            {
                if (e.RowIndex < 0 || e.ColumnIndex < 0 || e.CellStyle is null)
                    return;

                string columnName =
                    _lines.Columns[e.ColumnIndex].Name;

                if (columnName == "OperationStatus")
                {
                    e.CellStyle.ForeColor =
                        Convert.ToString(e.Value) == "가동"
                            ? Color.SeaGreen
                            : Color.Firebrick;
                }

                if (columnName == "Kind")
                {
                    e.CellStyle.ForeColor =
                        Convert.ToString(e.Value) == "실제"
                            ? Color.RoyalBlue
                            : Color.DimGray;
                }
            };
        }

        private void OpenLineDetail(
            object? sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
                return;

            var row = _lines.Rows[e.RowIndex];
            if (row.IsNewRow || row.DataBoundItem == null)
                return;

            if (row.Cells["IsReal"].Value is not bool isReal || !isReal)
            {
                MessageBox.Show(
                    this,
                    "대표 실제 라인을 더블클릭해 주세요.",
                    "라인 선택",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            if (row.Cells["Id"].Value is not int lineId)
                return;

            try
            {
                using var detail = new LineDetailForm(
                    lineId, _service, _detailService);
                detail.ShowDialog(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    this,
                    "상세 화면을 열지 못했습니다.\r\n" + ex.Message,
                    "화면 오류",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void AddColumn(
            string property, string title, float weight)
        {
            _lines.Columns.Add(
                new DataGridViewTextBoxColumn
                {
                    Name = property,
                    DataPropertyName = property,
                    HeaderText = title,
                    FillWeight = weight,
                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                });
        }

        private async Task RefreshAsync()
        {
            if (_loading)
                return;

            _loading = true;
            _refresh.Enabled = false;
            _status.Text = "데이터를 불러오는 중입니다.";

            try
            {
                var linesTask = _service.GetLinesAsync();
                var issuesTask = _service.GetIssuesAsync();

                await Task.WhenAll(linesTask, issuesTask);

                if (IsDisposed || Disposing)
                    return;

                var lines = await linesTask;
                var issues = await issuesTask;

                _totalValue.Text = lines.Count.ToString();
                _runningValue.Text = lines.Count(
                    x => x.OperationStatus == "가동").ToString();
                _issueValue.Text = issues.Count(
                    x => x.Status != IssueStatus.Closed).ToString();
                _completionValue.Text = issues.Count(
                    x => x.Status ==
                        IssueStatus.CompletionRequested).ToString();

                // 화면 표시용 데이터로 변환.
                // 공용 DTO는 변경하지 않음.
                _lines.DataSource = lines.Select(x => new
                {
                    x.Id,
                    x.IsReal,
                    x.Name,
                    Kind = x.IsReal ? "실제" : "가상",
                    x.OperationStatus,
                    x.InspectionStatus,
                    x.NormalCount,
                    x.DefectCount,
                    x.UndeterminedCount,
                    DefectRate =
                        x.NormalCount + x.DefectCount == 0
                            ? "-"
                            : $"{x.DefectCount * 100.0 /
                                (x.NormalCount + x.DefectCount):0.0}%",
                    x.UpdatedAt
                }).ToList();

                _status.Text =
                    $"조회 완료: {DateTime.Now:HH:mm:ss}  |  " +
                    "불량률 = 불량 ÷ (정상 + 불량), 판정 불가 제외";
            }
            catch (Exception ex)
            {
                if (!IsDisposed && !Disposing)
                {
                    _status.Text =
                        "조회 실패: " + ex.Message;
                }
            }
            finally
            {
                _loading = false;

                if (!IsDisposed && !Disposing)
                    _refresh.Enabled = true;
            }
        }

        private static Label MetricValue()
        {
            return new Label
            {
                Text = "-",
                Dock = DockStyle.Fill,
                Font = new Font(
                    "맑은 고딕", 25F, FontStyle.Bold),
                ForeColor = Color.FromArgb(35, 100, 180),
                TextAlign = ContentAlignment.MiddleLeft
            };
        }

        private static Control MetricCard(
            string title, Label value)
        {
            var card = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Margin = new Padding(4, 8, 8, 12),
                Padding = new Padding(15, 8, 10, 5),
                ColumnCount = 1,
                RowCount = 2
            };

            card.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 25));
            card.RowStyles.Add(
                new RowStyle(SizeType.Percent, 100));

            card.Controls.Add(new Label
            {
                Text = title,
                Dock = DockStyle.Fill,
                ForeColor = Color.DimGray
            }, 0, 0);

            card.Controls.Add(value, 0, 1);

            return card;
        }
    }
}





