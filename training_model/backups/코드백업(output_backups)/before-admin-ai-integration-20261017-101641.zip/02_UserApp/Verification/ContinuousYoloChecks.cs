using System.Reflection;
using OpenCvSharp;
using ProductionLine.Shared;
using ProductionLine.UserApp;
using ProductionLine.Vision;

namespace ProductionLine.Verification;

internal static class ContinuousYoloChecks
{
    private const BindingFlags Flags = BindingFlags.Instance | BindingFlags.NonPublic;
    private static T Field<T>(object instance, string name) =>
        (T)instance.GetType().GetField(name, Flags)!.GetValue(instance)!;
    private static object? Call(object instance, string name, params object[] args) =>
        instance.GetType().GetMethod(name, Flags)!.Invoke(instance, args);
    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
        Console.WriteLine("PASS: " + message);
    }

    public static void Run()
    {
        Application.SetHighDpiMode(HighDpiMode.SystemAware);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        var imagePath = Environment.GetCommandLineArgs().Skip(2).FirstOrDefault()
            ?? throw new ArgumentException("Pass an iPhone sample image after --continuous-yolo.");
        var phone = File.ReadAllBytes(imagePath);
        using var blank = new Mat(1080, 1920, MatType.CV_8UC3, Scalar.Black);
        using var server = new TestServer();
        using var api = new ProductionLineApiClient(server.Url);
        api.LoginAsync("test", "test").GetAwaiter().GetResult();
        using var form = new UserMainForm(api);
        var feed = new MutableFeed(phone);
        form.Shown += async (_, _) =>
        {
            try
            {
                for (var attempt = 0; attempt < 200 && Field<bool>(form, "_loading"); attempt++)
                    await Task.Delay(25);
                await (Task)Call(form, "RefreshAsync", false)!;
                Field<System.Windows.Forms.Timer>(form, "_refresh").Stop();
                Field<System.Windows.Forms.Timer>(form, "_frames").Stop();
                typeof(UserMainForm).GetField("_camera", Flags)!.SetValue(form, feed);
                await (Task)Call(form, "StartInspectionAsync")!;
                var timer = Field<System.Windows.Forms.Timer>(form, "_inspectionTimer");
                timer.Stop();
                Check(timer.Interval == 100, "100ms target interval");
                Check(server.InspectionCount == 1, "first phone counted once using actual ONNX model");
                var picture = Field<PictureBox>(form, "_video");
                var previousImage = picture.Image;
                await Task.Delay(110);
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(!ReferenceEquals(previousImage, picture.Image), "same phone gets a fresh annotated frame");
                Check(server.InspectionCount == 1, "continuous frames do not duplicate product counts");
                var result = Field<Label>(form, "_result");
                Check(result.Text.StartsWith("YOLO 연속 검사"), "live YOLO result stays visible");
                await (Task)Call(form, "RefreshAsync", false)!;
                Check(result.Text.StartsWith("YOLO 연속 검사"), "server refresh does not overwrite live result");
                feed.Image = blank.ToBytes(".jpg");
                await Task.Delay(300);
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(!Field<bool>(form, "_productPresent"), "empty belt rearms product counting");
                feed.Image = phone;
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(server.InspectionCount == 2, "returning phone counts as next product");
                Call(form, "StopInspection", "test stop");
                previousImage = picture.Image;
                await (Task)Call(form, "InspectCameraAsync")!;
                Check(ReferenceEquals(previousImage, picture.Image) && server.InspectionCount == 2,
                    "stop prevents analysis and additional records");
                Check(!Field<bool>(form, "_inspectionBusy"), "no analysis left running");
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine(exception);
                Environment.ExitCode = 1;
            }
            finally
            {
                Call(form, "DisconnectCamera");
                form.Close();
            }
        };
        Application.Run(form);
    }

    private sealed class MutableFeed(byte[] image) : ICameraFeed
    {
        private long _sequence;
        public byte[] Image { get; set; } = image;
        public string? Error => null;
        public CameraFrame Latest => new(Image, ++_sequence, DateTime.UtcNow);
        public Task Completion => Task.CompletedTask;
        public void Dispose() { }
    }
}
