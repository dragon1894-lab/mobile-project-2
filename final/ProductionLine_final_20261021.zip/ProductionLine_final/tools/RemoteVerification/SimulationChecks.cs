using System.Reflection;
using _01_AdminApp;
using _01_AdminApp.Services;
using ProductionLine.Shared;

internal static class SimulationChecks
{
    private const BindingFlags Flags=BindingFlags.NonPublic|BindingFlags.Instance;
    private static T Field<T>(object o,string name)=>(T)o.GetType().GetField(name,Flags)!.GetValue(o)!;
    private static void Check(bool condition,string text){if(!condition)throw new Exception(text);Console.WriteLine("PASS: "+text);}
    private static IEnumerable<Control> Descendants(Control root)
    { foreach(Control child in root.Controls){yield return child;foreach(var next in Descendants(child))yield return next;} }
    private static string Frame(LineStatusCard card)
    {
        var view=Field<Control>(card,"_conveyor");var simulation=Field<object>(view,"_simulation");
        return $"{simulation.GetType().GetProperty("Stage")!.GetValue(simulation)}:{Field<double>(simulation,"_elapsed"):R}:{Field<double>(view,"_beltPhase"):R}";
    }
    public static async Task RunAsync(string output,ProductionLineApiClient? api=null)
    {
        IDashboardService dashboard=api==null?new MockDashboardService():new ApiDashboardService(api);
        ILineDetailService detail=api==null?new MockLineDetailService():new ApiLineDetailService(api);
        IUserService users=api==null?new MockUserService():new ApiUserService(api);
        var before=api==null?null:await api.GetRemoteLineAsync(1);
        using var main=new AdminMainForm(new("admin","관리자",UserRole.Admin,true,new[]{1,2,3,4}),dashboard,detail,users,api)
            {ShowInTaskbar=false,StartPosition=FormStartPosition.Manual,Location=new Point(-3000,-3000)};
        main.Show();var cards=Field<Dictionary<int,LineStatusCard>>(main,"_cards");
        for(var i=0;cards.Count<4;i++){if(i>100)throw new TimeoutException("Simulation cards missing");await Task.Delay(50);}
        void CheckGrid(string size)
        {
            var panel=Field<Panel>(main,"_lineList");
            Check(cards[1].Top==cards[2].Top && cards[3].Top==cards[4].Top && cards[1].Left==cards[3].Left && cards[2].Left==cards[4].Left && cards[1].Top<cards[3].Top,
                "four lines use requested 1/2 above 3/4 grid at "+size);
            Check(!panel.AutoScroll && !panel.HorizontalScroll.Visible && cards.Values.All(c=>panel.ClientRectangle.Contains(c.Bounds)) &&
                cards.Values.All(c=>Field<Control>(c,"_conveyor").Height>=30),"all cards and simulation drawings fit without scrolling at "+size);
        }
        CheckGrid("default size");main.Size=main.MinimumSize;await Task.Delay(100);CheckGrid("minimum size");
        main.ClientSize=new Size(1600,1000);await Task.Delay(100);CheckGrid("larger size");
        main.ClientSize=new Size(1280,950);await Task.Delay(100);
        var toggle=Field<Button>(main,"_play");
        Check(toggle.Enabled && toggle.Text=="정지","simulation starts playing without requiring Arduino state");
        Check(new[]{2,3,4}.All(id=>Field<LineStatusDto>(cards[id],"_line").NormalCount>0 && Field<LineStatusDto>(cards[id],"_line").Hardware==null),"virtual lines have separate sample counts without fake hardware readings");
        var frames=cards.ToDictionary(p=>p.Key,p=>Frame(p.Value));await Task.Delay(350);
        Check(cards.All(p=>Frame(p.Value)!=frames[p.Key]),"all four simulations advance, including offscreen lines");
        toggle.PerformClick();frames=cards.ToDictionary(p=>p.Key,p=>Frame(p.Value));await Task.Delay(1500);
        Check(cards.All(p=>Frame(p.Value)==frames[p.Key]) && toggle.Text=="재생","one click freezes all simulations through automatic refresh");
        Check(new[]{2,3,4}.All(id=>Field<LineStatusDto>(cards[id],"_line").OperationStatus=="정지"),"virtual status labels show paused simulation");
        var ticks=Field<int>(main,"_simulationTicks");await Task.Delay(1100);
        Check(Field<int>(main,"_simulationTicks")==ticks,"virtual production time does not advance while paused");
        toggle.PerformClick();await Task.Delay(350);
        Check(cards.All(p=>Frame(p.Value)!=frames[p.Key]) && toggle.Text=="정지","second click resumes all simulations from retained state");
        Check(Field<Label[]>(main,"_values").Length==5 && Descendants(main).OfType<Button>().Any(c=>c.Text=="완료 요청 확인"),"completion request review button is available while dashboard keeps five metrics");
        if(api!=null)
        {
            var after=await api.GetRemoteLineAsync(1);
            Check(after.Commands.Count==before!.Commands.Count,"simulation toggle sends no real hardware remote commands");
        }
        using(var image=new Bitmap(main.Width,main.Height)){main.DrawToBitmap(image,new Rectangle(Point.Empty,image.Size));image.Save(Path.Combine(output,"admin-simulation-playing.png"));}
        toggle.PerformClick();using(var image=new Bitmap(main.Width,main.Height)){main.DrawToBitmap(image,new Rectangle(Point.Empty,image.Size));image.Save(Path.Combine(output,"admin-simulation-paused.png"));}
        main.Close();
    }
}
