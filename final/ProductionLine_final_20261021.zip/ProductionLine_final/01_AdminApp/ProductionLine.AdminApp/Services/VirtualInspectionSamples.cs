using ProductionLine.Shared;

namespace _01_AdminApp.Services;

// Display-only examples for the prototype's virtual lines. Never save as real inspections.
internal static class VirtualInspectionSamples
{
    private static readonly DateTimeOffset CreatedAt = DateTimeOffset.Now;
    public static List<InspectionDto> Get(int lineId)
    {
        if (lineId is < 2 or > 4) return new();
        var results = new[] { InspectionResultType.Normal, InspectionResultType.Normal,
            InspectionResultType.Defect, InspectionResultType.Normal, InspectionResultType.Undetermined };
        var reasons = new[] { "iphone_14_white · 정상", "iphone_16_white · 정상",
            "crack_phone · iphone_12pro_silver · 파손 예시", "iphone_12pro_silver · 정상", "영상 흐림 · 판정 불가 예시" };
        return Enumerable.Range(0,5).Select(i => new InspectionDto(
            new Guid($"{lineId:X8}-0000-4000-8000-{i+1:X12}"), lineId, results[i],
            i == 2 ? .63 : i == 4 ? .52 : .96, i == 4 ? .48 : .94,
            "[가상 예시] " + reasons[i], CreatedAt.AddMinutes(-(lineId+i*2)), HasImage:false)).ToList();
    }
}
