using System.Collections.Concurrent;
using ProductionLine.Shared;

namespace ProductionLine.Server.Infrastructure;

// Latest live state only. Never substitute simulated values for missing sensors.
public sealed class LineHardwareStore
{
    private readonly ConcurrentDictionary<int, LineHardwareStatusDto> _latest = new();
    private readonly object _historyGate = new();
    private readonly Dictionary<int, List<LineHardwareStatusDto>> _history = new();
    public IReadOnlyList<LineHardwareStatusDto> History(int lineId)
    {
        lock (_historyGate) return _history.TryGetValue(lineId, out var samples) ? samples.ToArray() : Array.Empty<LineHardwareStatusDto>();
    }
    public LineStatusDto Attach(LineStatusDto line)
    {
        if (!line.IsReal)
        {
            // Virtual conveyors follow the representative line's actual state.
            // Never attach real sensor readings or counts to a virtual line.
            var linked = _latest.TryGetValue(1, out var main) && main.IsFresh;
            return line with
            {
                OperationStatus = !linked ? "대표 라인 통신 미확인" : main!.EmergencyStopped ? "긴급 정지" : main!.BeltRunning ? "가동" : "정지",
                InspectionStatus = "가상 데이터 · D12/벨트 상태 연동"
            };
        }
        if (!line.IsReal || !_latest.TryGetValue(line.Id, out var hardware)) return line;
        return line with
        {
            Hardware = hardware,
            OperationStatus = !hardware.IsFresh ? "장비 통신 미확인"
                : hardware.EmergencyStopped ? "긴급 정지" : hardware.BeltRunning ? "가동" : "정지"
        };
    }

    public LineHardwareStatusDto Update(int lineId, UpdateLineHardwareRequest value)
    {
        if (value.TemperatureCelsius is double t && (!double.IsFinite(t) || t < -40 || t > 125) ||
            value.HumidityPercent is double h && (!double.IsFinite(h) || h < 0 || h > 100) ||
            value.SorterAngle is < 0 or > 180 || value.GasAnalogValue is < 0 or > 1023 || value.EmergencyStopped && value.BeltRunning || value.SpeedBoosted && !value.BeltRunning)
            throw new ArgumentException("센서 값이나 구동 상태가 올바르지 않습니다.");
        var status = new LineHardwareStatusDto(value.Connected, value.TemperatureCelsius,
            value.HumidityPercent, value.GasDetected, value.EmergencyStopped, value.BeltRunning,
            value.SorterAngle, value.Sorting, DateTimeOffset.UtcNow, value.SpeedBoosted, value.GasAnalogValue, value.GasWarmingUp);
        _latest[lineId] = status;
        lock (_historyGate)
        {
            if (!_history.TryGetValue(lineId, out var samples)) _history[lineId] = samples = new();
            if (samples.Count == 0 || status.ReceivedAt - samples[^1].ReceivedAt >= TimeSpan.FromSeconds(2) || !status.Connected)
                samples.Add(status);
            samples.RemoveAll(s => status.ReceivedAt - s.ReceivedAt > TimeSpan.FromMinutes(10));
            if (samples.Count > 600) samples.RemoveRange(0, samples.Count - 600);
        }
        return status;
    }
}
